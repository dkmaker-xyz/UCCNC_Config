﻿#pragma warning disable CS0649

using System.Collections.Generic;
using System.Drawing;

namespace UCCNC
{
   public class AS3interfaceClass
   {
      public static string HtmlEncode(string text) { return ""; }

      //public AS3interfaceClass(UCCNC.Form1 mainform, int screennumber, OpenTK.GLControl screenobj) { }
      public AS3interfaceClass() { }

      //public UCCNC.Form1 mainform;
      //public UCCNC.GUI mainGUI;
      public UC100.Stat UCstat;
      public int screennumber;
      public int screensizeX;
      public int screensizeY;
      //public OpenTK.GLControl screenobj;
      public List<int> Layeriniselects;
      public UCCNC.GLparams[] glpar;
      public int CAMcanvassizeX;
      public int CAMcanvassizeY;
      public string gcodetext;

      public void Setjogpaneltabsize(int tabsize) { }
      public void Setscreensize(int x, int y) { }
      public void SendallIOledstoscreen(double Xpos, double Ypos, double Xgrid, double Ygrid, int sizeX, int sizeY, int outtypeLEDnum, int intypeLEDnum, int layernum) { }
      public void Addallioleds(double Xpos, double Ypos, double Xgrid, double Ygrid, int sizeX, int sizeY, int outtypeLEDnum, int intypeLEDnum, int layernum) { }
      public void Loadpicture(string pictureupURL, string picturedownURL, int picturenumber, bool IsLastpicturetoload) { }
      public void Sendlisttoscreen(string labelfont, string textalign, int fontsize, int fontcolor, int posX, int posY, int Width, int Height, int labelnumber, int layernumber) { }
      public void Addlist(string labelfont, string textalign, int fontsize, int fontcolor, int posX, int posY, int Width, int Height, int labelnumber, int layernumber) { }
      public void Addlist(string labelfont, string textalign, int fontsize, int fontcolor, int backcolor, double transparency, int posX, int posY, int Width, int Height, int labelnumber, int layernumber) { }
      public void Additemtolist(string val, int labelnumber) { }
      public void Additemtolistbeginning(string val, int labelnumber) { }
      public List<string> Getlist(int labelnumber) { return new List<string>(); }
      public List<string> GetMDIhistory() { return new List<string>(); }
      public void ClearMDIhistory() { }
      public void Addslider(int x, int y, int length, int colorcode1, int colorcode2, int minvalue, int maxvalue, bool isvertical, int fieldnumber, int layernumber) { }
      public void Addslider(int x, int y, int length, int colorcode1, int colorcode2, int minvalue, int maxvalue, bool isvertical, bool acceptclick, int fieldnumber, int layernumber) { }
      public void Setslider(int value, int fieldnumber) { }
      public void Addcomboboxitem(string val, int labelnumber) { }
      public void Clearcomboboxitems(int labelnumber) { }
      public void Validatenewcomboboxitems(int labelnumber) { }
      public void Clearlist(int labelnumber) { }
      public int Getselectedindexinlist(int labelnumber) { return 0; }
      public int Setselectedindexinlist(int labelnumber, int index) { return 0; }
      public void Addbutton(double x, double y, double w, double h, bool toggletype, bool blinktype, int picturenumber, int buttonnumber, int layernumber) { }
      public void Sendcolorpickertoscreen(double x, double y, double w, double h, int colorpickernumber, int layernumber) { }
      public void Addcolorpick(double x, double y, double w, double h, int colorpickernumber, int layernumber) { }
      public void Setcolorpickercolor(int val, int labelnumber) { }
      public int Getcolorpickercolor(int labelnumber) { return 0; }
      public void Addimageview(double x, double y, double w, double h, int labelnumber, int layernumber) { }
      public void Sendimageview(Image img, int ID) { }
      public void SendLEDtoscreen(double x, double y, double w, double h, int picturenumber, int LEDnumber, int layernumber) { }
      public void Addled(double x, double y, double w, double h, int picturenumber, int LEDnumber, int layernumber) { }
      public void Addled(double x, double y, double w, double h, bool blinktype, int picturenumber, int LEDnumber, int layernumber) { }
      public void Sendbackgroundtoscreen(double x, double y, double w, double h, int picturenumber, int backgroundnumber, int layernumber) { }
      public void Addbackground(double x, double y, double w, double h, int picturenumber, int backgroundnumber, int layernumber) { }
      public void Switchbutton(bool Ison, int Buttonnumber) { }
      public void Sendallbuttonsup() { }
      public void Addtexttoremember(string val) { }
      public void UpdateLEDs(int[] LEDstates) { }
      public void Sendfilltoscreen(int fillcolor, int posX, int posY, int sizeX, int sizeY, double transparency, int labelnumber, int layernumber) { }
      public void Addfill(int fillcolor, int posX, int posY, int sizeX, int sizeY, double transparency, int labelnumber, int layernumber) { }
      public void AddUCCAM(int posX, int posY, int sizeX, int sizeY, int labelnumber, int layernumber) { }
      public void AddUCCAM(int fillcolor, int posX, int posY, int sizeX, int sizeY, int labelnumber, int layernumber) { }
      public void CAMClearcanvas(int fillcolor) { }
      public void ShowAllfill() { }
      public void HideAllfill() { }
      public void Sendcomboboxtoscreen(int posX, int posY, int Width, int fontsize, int fontcolor, int Numberofaxis, int labelnumber, int layernumber) { }
      public void Addcombobox(string font, int posX, int posY, int Width, int fontsize, int fontcolor, int Numberofaxis, int labelnumber, int layernumber) { }
      public void Addcombobox(int posX, int posY, int Width, int fontsize, int fontcolor, int Numberofaxis, int labelnumber, int layernumber) { }
      public void Sendstaticlabeltoscreen(string labeltext, string labelfont, string textalign, int fontsize, int fontcolor, int posX, int posY, int layernumber) { }
      public void Addlabel(string labeltext, string labelfont, string textalign, int fontsize, int fontcolor, int posX, int posY, int layernumber) { }
      public void Sendcodeviewtoscreen(string labeltext, string labelfont, string textalign, int fontsize, int fontcolor, int posX, int posY, int Width, int Height, int layernumber) { }
      public void Addcodeview(string labeltext, string labelfont, string textalign, int fontsize, int fontcolor, int posX, int posY, int Width, int Height, int layernumber) { }
      public void Updatecodeviewcolors(int understandcolor, int notunderstandcolor) { }
      public void Sendcheckboxtoscreen(string labeltext, string labelfont, int fontsize, int fontcolor, int posX, int posY, int boxnumber, int layernumber) { }
      public void Addcheckbox(string labeltext, string labelfont, int fontsize, int fontcolor, int posX, int posY, int boxnumber, int layernumber) { }
      public void CAMSendimage(Image bmp) { }
      public void Setscrollproperties(int max) { }
      public void Setscrollposition(int pos) { }
      public string Getfield(int labelnumber) { return ""; }
      public bool GetLED(int LEDnumber) { return false; }
      public void SetLED(bool val, int LEDnumber) { }
      public bool Getbuttonstate(int buttonnumber) { return false; }
      public bool Getbutton(int buttonnumber) { return false; }
      public string Getcomboboxselection(int labelnumber) { return ""; }
      public void Updatecomboboxselection(int selectedindex, int labelnumber) { }
      public bool Getcheckboxstate(int checkboxnumber) { return false; }
      public void Setcheckboxstate(bool Ison, int Boxnumber) { }
      public int Getfieldint(int labelnumber) { return 0; }
      public double Getfielddouble(int labelnumber) { return 0; }
      public string GetXMLreturnvalue(string returnval) { return ""; }
      public void Sendtabtoscreen(string labeltext, string labelfont, string textalign, int fontsize, int fontcolor, int posX, int posY, int labelwidth, int labelheight, int picturenumber, int labelnumber, int parentnumber) { }
      public void Addtab(string labeltext, string labelfont, string textalign, int fontsize, int fontcolor, int posX, int posY, int labelwidth, int labelheight, int picturenumber, int labelnumber, int parentnumber) { }
      public void Addmainlayer() { }
      public void selectlayer(int layernumber) { }
      public void Sendfieldtoscreen(string labeltext, string labelfont, string textalign, int fontsize, int fontcolor, double posX, double posY, int intextboxwidth, string type, double min, double max, int labelnumber, int parentnumber) { }
      public void Addfield(string labeltext, string labelfont, string textalign, int fontsize, int fontcolor, double posX, double posY, int intextboxwidth, string type, double min, double max, int labelnumber, int parentnumber) { }
      public void Setfield(double val, int labelnumber) { }
      public void Validatefield(int labelnumber) { }
      public void Focusoutoffield() { }
      public void Setinputnumberformat(bool Fixeddecimal, int Decimalplaces, int labelnumber) { }
      public void Filterinputtext(string val, int labelnumber) { }
      public void Filterfieldtext(string val, int labelnumber) { }
      public void Setfieldtext(string val, int labelnumber) { }
      public void SendMDItoscreen(string labeltext, string labelfont, string textalign, int fontsize, int fontcolor, int posX, int posY, int intextboxwidth, int labelnumber, int parentnumber) { }
      public void Addmdi(string labeltext, string labelfont, string textalign, int fontsize, int fontcolor, int posX, int posY, int intextboxwidth, int labelnumber, int parentnumber) { }
      public void BlinkMDI(int codeOK, int labelnumber) { }
      public void Addtoolpath(int x, int y, int width, int height, int layer) { }
   }
}