﻿#pragma warning disable 0649

namespace UCCNC
{
   public struct Allvarstruct
   {
      public double? Avar;
      public double? Bvar;
      public double? Cvar;
      public double? Dvar;
      public double? Evar;
      public double? Fvar;
      public double? Gvar;
      public double? Hvar;
      public double? Ivar;
      public double? Jvar;
      public double? Kvar;
      public double? Lvar;
      public double? Mvar;
      public double? Nvar;
      public double? Ovar;
      public double? Pvar;
      public double? Qvar;
      public double? Rvar;
      public double? Svar;
      public double? Tvar;
      public double? Uvar;
      public double? Vvar;
      public double? Wvar;
      public double? Xvar;
      public double? Yvar;
      public double? Zvar;
      public bool Isvar;
   }
}