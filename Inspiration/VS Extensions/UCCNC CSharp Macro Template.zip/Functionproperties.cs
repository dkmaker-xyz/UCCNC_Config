﻿#pragma warning disable 0649

namespace UCCNC
{
   public struct Functionproperties
   {
      public int functioncode;
      public string functionname;
      public string functiondescription;
   }
}