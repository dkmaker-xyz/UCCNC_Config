﻿#pragma warning disable CS0414

using System;
using System.Windows.Forms;
using System.Drawing;
using System.Threading;
using System.Collections.Generic;

namespace UCCNC
{
   internal class Macroclass
   {
      public Macroclass() { }

      private AS3interfaceClass AS3 = null;
      private AS3interfaceClass AS3jog = null;
      private Executer exec = null;

      //
      //  Place program code for the #Events section of the UCCNC macro within the boundaries of the
      //  EventsRegion.  Do not remove or alter the lines containing the #region or #endregion directives.
      //
      #region EventsRegion
      #endregion

      public void Runmacro(Executer exec, double? Evar, double? Hvar, double? Qvar, double? Pvar, Allvarstruct Allvars)
      {
         //
         //  Place main UCCNC macro statements inside the boundaries of the MacroBody region.  Do not
         //  remove or alter the lines containing the #region or #endregion directives.
         //
         #region MacroBody
         #endregion
      }

      #region EnumRegion

      //
      //  Do not remove or alter any lines within the EnumRegion.
      //
      internal enum LED : int
      {
         Nofunction, OutputPT1PN1, OutputPT1PN2, OutputPT1PN3, OutputPT1PN4, OutputPT1PN5, OutputPT1PN6, OutputPT1PN7, OutputPT1PN8, OutputPT1PN9, OutputPT1PN10, OutputPT1PN11
           , OutputPT1PN12, OutputPT1PN13, OutputPT1PN14, OutputPT1PN15, OutputPT1PN16, OutputPT1PN17, Idle, Run, Jog, Dwell, Backlash, Home, Probing, Reset, Hardlimit, Limitsoverride
           , Toolchangeinprogress, Xlimitpositive, Ylimitpositive, Zlimitpositive, Alimitpositive, Blimitpositive, Climitpositive, Index, Estop, Probe, Xlimitnegative, Ylimitnegative
           , Zlimitnegative, Alimitnegative, Blimitnegative, Climitnegative, Xhome, Yhome, Zhome, Ahome, Bhome, Chome, SpindleCW, SpindleCCW, Miston, Floodon, Cyclestart, Runsingleline
           , Xhomed, Yhomed, Zhomed, Ahomed, Bhomed, Chomed, Machinecoords, THCon, THCup, THCdown, THCenabled, Softlimitsenabled, THCdelay, OutputPT2PN1, OutputPT2PN2, OutputPT2PN3
           , OutputPT2PN4, OutputPT2PN5, OutputPT2PN6, OutputPT2PN7, OutputPT2PN8, OutputPT2PN9, OutputPT2PN10, OutputPT2PN11, OutputPT2PN12, OutputPT2PN13, OutputPT2PN14, OutputPT2PN15
           , OutputPT2PN16, OutputPT2PN17, OutputPT3PN1, OutputPT3PN2, OutputPT3PN3, OutputPT3PN4, OutputPT3PN5, OutputPT3PN6, OutputPT3PN7, OutputPT3PN8, OutputPT3PN9, OutputPT3PN10
           , OutputPT3PN11, OutputPT3PN12, OutputPT3PN13, OutputPT3PN14, OutputPT3PN15, OutputPT3PN16, OutputPT3PN17, OutputPT4PN1, OutputPT4PN2, OutputPT4PN3, OutputPT4PN4, OutputPT4PN5
           , OutputPT4PN6, OutputPT4PN7, OutputPT4PN8, OutputPT4PN9, OutputPT4PN10, OutputPT4PN11, OutputPT4PN12, OutputPT4PN13, OutputPT4PN14, OutputPT4PN15, OutputPT4PN16, OutputPT4PN17
           , OutputPT5PN1, OutputPT5PN2, OutputPT5PN3, OutputPT5PN4, OutputPT5PN5, OutputPT5PN6, OutputPT5PN7, OutputPT5PN8, OutputPT5PN9, OutputPT5PN10, OutputPT5PN11, OutputPT5PN12
           , OutputPT5PN13, OutputPT5PN14, OutputPT5PN15, OutputPT5PN16, OutputPT5PN17, MPGAPIN, MPGBPIN, EnableXaxis, EnableYaxis, EnableZaxis, EnableAaxis, EnableBaxis, EnableCaxis
           , Jogmodecontinous, Jogmodestep, Jograte0001 = 148, Jograte0010, Jograte0100, Jograte1000, MPGmodecont, MPGmodesingle, MPGmodemulti, MPGXaxisselect, MPGYaxisselect
           , MPGZaxisselect, MPGAaxisselect, MPGBaxisselect, MPGCaxisselect, Offlinemode = 212, Sync_thread, EncoderApin, EncoderBpin, MDIrunning, Feedhold, Isdemomode, Laserdataloaded
           , Laserrunning, OutputPT5PN26, OutputPT5PN27, OutputPT5PN28, OutputPT5PN29, OutputPT5PN30, OutputPT5PN31, OutputPT5PN32, OutputPT5PN33, M0stopactive, M1stopactive
           , M60stopactive, Pause, THCAntidiveactive, OutputPT1PN94, OutputPT1PN95, MPGJogOn, THCarcon_emulation, THCup_emulation, THCdown_emulation, THCantidiveenabled, THCdelayenabled
           , THCantidownenabled, SafeProbeModeactive, ProbedOK, Digitizing, JogSafeProbeModeactive, M1optionalstopenabled, ScaleXactive, ScaleYactive, ScaleZactive, ScaleAactive
           , ScaleBactive, ScaleCactive, G68Rotationactive, TCPfollowmodeactive, FROdisabled, SROdisabled, FROover100, FROunder100, SROover100, SROunder100, Proberadiusdisabled
           , Rapidmovementselected, ProbeError = 300, ProbePaused, Axis1Disable, Axis2Disable, Axis3Disable, TouchProbeWpCoordsSaved, MobileProbeCoordsSaved, FixedProbeCoordsSaved
           , MobileWpReferenced, FixedWpReferenced
      }

      internal enum BTN : int
      {
         Nofunction, ZeroX = 100, ZeroY, ZeroZ, ZeroA, ZeroB, ZeroC, ZeroAll, HomeX, HomeY, HomeZ, HomeA, HomeB, HomeC, HomeAll, M3toggle, M4toggle, M7toggle, M8toggle, G54select
            , G55select, G56select, G57select, G58select, G59select, OpenGcodefile, CloseGcodefile, EditGcodefile, RewindGcodefile, Cyclestart, Runsingleline, Cyclestop, Gotozero
            , FROincrease, FROdecrease, SROincrease, SROdecrease, Toolpathzoomin, Toolpathzoomout, Toolpathzoomcontents, Toolpathview45, Toolpathviewright, Toolpathviewleft
            , Toolpathviewtop, ToolpathviewISO, Resettoggle, Offlinetoggle, Limitsoverridetoggle, JogXpos, JogXneg, JogYpos, JogYneg, JogZpos, JogZneg, JogApos, JogAneg, JogBpos
            , JogBneg, JogCpos, JogCneg, Jograteincrease, Jogratedecrease, Jogmodecont, Jogmodestep, Jogsteprate0010 = 164, Jogsteprate0100, Jogsteprate1000, Savesettings
            , Applysettings, Setnextline, G54offsetcurrentpos, G55offsetcurrentpos, G56offsetcurrentpos, G57offsetcurrentpos, G58offsetcurrentpos, G59offsetcurrentpos, G54offsetclear
            , G55offsetclear, G56offsetclear, G57offsetclear, G58offsetclear, G59offsetclear, TooloffsetclearX, TooloffsetclearY, TooloffsetclearZ, TooloffsetclearA, TooloffsetclearB
            , TooloffsetclearC, Listprofiles, Deleteprofile, Loadprofile, Createnewprofile, DoXMLimport, Gotoparkposition1, Gotoparkposition2, Gotoparkposition3, Toollengthmeasurement
            , Machinecoords, CalibrateX, CalibrateY, CalibrateZ, CalibrateA, CalibrateB, CalibrateC, Softlimitstoggle, THCtoggle, Zeroworktimer = 218, ClearG92offset, MPGXaxisselect
            , MPGYaxisselect, MPGZaxisselect, MPGAaxisselect, MPGBaxisselect, MPGCaxisselect, MPGcontmodeselect, MPGsinglemodeselect, MPGmultimodeselect, JogXplusoff, JogXminusoff
            , JogYplusoff, JogYminusoff, JogZplusoff, JogZminusoff, JogAplusoff, JogAminusoff, JogBplusoff, JogBminusoff, JogCplusoff, JogCminusoff, Jogsteprate0001, CAM_ImportDXF = 501
            , CAM_Generatetoolpath, CAM_Generategcode, M3on, M3off, M4on, M4off, M7on, M7off, M8on, M8off, Reseton, Resetoff, Offlineon, Offlineoff, Machinecoordson, Machinecoordsoff
            , Softlimitson, Softlimitsoff, THCon, THCoff, Feedholdtoggle, Feedholdon, Feedholdoff, Configplugins, Editscreen, Savealloffsets, Clearstatusmessages, THCAntiDiveon
            , THCAntiDiveoff, THCAntiDivetoggle, Configmacroloops, THCDelayon, THCDelayoff, THCDelaytoggle, THCarconsignalon_emulation, THCarconsignaloff_emulation
            , THCupsignalon_emulation, THCupsignaloff_emulation, THCdownsignalon_emulation, THCdownsignaloff_emulation, THCAntiDownon, THCAntiDownoff, THCAntiDowntoggle, Safeprobemodeon
            , Safeprobemodeoff, Safeprobemodetoggle, Operatorlock, Showstatistics, ShowSpindlepulleys, Digitize_setfilename, JogSafeprobemodeon, JogSafeprobemodeoff
            , JogSafeprobemodetoggle, ReloadGcodefile, JograteResetto100percent, FROResetto100percent, SROResetto100percent, M1optionalstopon, M1optionalstopoff, M1optionalstoptoggle
            , JogpanelShow = 770, JogpanelHide, JogpanelToggle, OpenSpindlePIDsetup, ToolpathTCPfollowOn, ToolpathTCPfollowOff, ToolpathTCPfollowToggle, ShowToolpathZplatesetup
            , ShowCutterRcompwarnings, OpenTooltabledetails, Savetooltabledatas, DereferenceAllHomes, CloseResetandQuestionForms, ChangetoolM6, Toggletoolpathdimensionsvisibility
            , Toolpathdimensionsvisibilityon, Toolpathdimensionsvisibilityoff, ProbeToolQuickJump = 800, ToolProbeMode, SimpleProbeMode, AngleProbeMode, PocketProbeMode, OuterProbeMode
            , InnerCornerProbeMode, OuterCornerProbeMode, RectangleInnerProbeMode, CircleInnerProbeMode, RectangleOuterProbeMode, CircleOuterProbeMode, InnerCornerBottomLeft = 813
            , InnerCornerBottomRight, InnerCornerTopRight, InnerCornerTopLeft, OuterCornerBottomLeft, OuterCornerBottomRight, OuterCornerTopRight, OuterCornerTopLeft, StartProbe
            , ProbeAxis1SelectX, ProbeAxis1SelectY, ProbeAxis1SelectZ, ProbeAxis1SelectA, ProbeAxis1SelectB, ProbeAxis1SelectC, ProbeAxis2SelectX, ProbeAxis2SelectY, ProbeAxis2SelectZ
            , ProbeAxis2SelectA, ProbeAxis2SelectB, ProbeAxis2SelectC, ProbeAxisCSelectX, ProbeAxisCSelectY, ProbeAxisCSelectZ, ProbeAxisCSelectA, ProbeAxisCSelectB, ProbeAxisCSelectC
            , TouchToolProbeMode, MobileToolProbeMode, FixedToolProbeMode, SetAsWpProbePos, ProbeInWpProbePos, GotoWpProbePos, SetAsMobileProbePos, SetAsFixedProbePos, GotoProbePos
            , RefCurrentAsWp, RefProbeAsWp, ZeroProbedAxis, ZeroOnAllOffsets, SingleProbeMode, EnableRetract, PauseBeforeProbe, CommonAxisSettings, ProbeInfo, GotoRef, Axis1CountGage
            , Axis1CountDia, Axis2CountGage, Axis2CountDia, MobileProbePosAEna, MobileProbePosBEna, MobileProbePosCEna, FixedProbePosAEna, FixedProbePosBEna, FixedProbePosCEna
            , SafeXPositive, SafeYPositive, SafeZPositive, SaveMobileProbePos, SaveWpReferences, OverrideProbeDia, LimitTraverseSpeed, SeparateSettingsPerMode, NoBlower, BlowWithM7
            , BlowWithM8, BlowUsingOutput, BlowerPinActiveLow, BlowToolProbes, BlowAllProbes, AirBlower
      }

      internal enum FLD : int
      {
         Nofunction, Xaxissteppin, Xaxisdirpin, Xaxislimitminuspin, Xaxislimitpluspin, Xaxishomepin, Xaxishomingspeedup, Xaxishomeoffset, Xaxisstepsper, Xaxisvelocity, Xaxisacceleration
            , Xaxissoftlimitminus, Xaxissoftlimitplus, Xaxiscompaccel, Xaxisbacklash, Xaxishomingspeeddown, Yaxissteppin, Yaxisdirpin, Yaxislimitminuspin, Yaxislimitpluspin, Yaxishomepin
            , Yaxishomingspeedup, Yaxishomeoffset, Yaxisstepsper, Yaxisvelocity, Yaxisacceleration, Yaxissoftlimitminus, Yaxissoftlimitplus, Yaxiscompaccel, Yaxisbacklash, Yaxishomingspeeddown
            , Zaxissteppin, Zaxisdirpin, Zaxislimitminuspin, Zaxislimitpluspin, Zaxishomepin, Zaxishomingspeedup, Zaxishomeoffset, Zaxisstepsper, Zaxisvelocity, Zaxisacceleration, Zaxissoftlimitminus
            , Zaxissoftlimitplus, Zaxiscompaccel, Zaxisbacklash, Zaxishomingspeeddown, Aaxissteppin, Aaxisdirpin, Aaxislimitminuspin, Aaxislimitpluspin, Aaxishomepin, Aaxishomingspeedup
            , Aaxishomeoffset, Aaxisstepsper, Aaxisvelocity, Aaxisacceleration, Aaxissoftlimitminus, Aaxissoftlimitplus, Aaxiscompaccel, Aaxisbacklash, Aaxishomingspeeddown, Baxissteppin
            , Baxisdirpin, Baxislimitminuspin, Baxislimitpluspin, Baxishomepin, Baxishomingspeedup, Baxishomeoffset, Baxisstepsper, Baxisvelocity, Baxisacceleration, Baxissoftlimitminus
            , Baxissoftlimitplus, Baxiscompaccel, Baxisbacklash, Baxishomingspeeddown, Caxissteppin, Caxisdirpin, Caxislimitminuspin, Caxislimitpluspin, Caxishomepin, Caxishomingspeedup
            , Caxishomeoffset, Caxisstepsper, Caxisvelocity, Caxisacceleration, Caxissoftlimitminus, Caxissoftlimitplus, Caxiscompaccel, Caxisbacklash, Caxishomingspeeddown, Estoppin, Probepin1
            , Indexpin, Indexprescaler, Chargepumppin, G54_CurrentcoordX = 97, G54_CurrentcoordY, G54_CurrentcoordZ, G54_CurrentcoordA, G54_CurrentcoordB, G54_CurrentcoordC, G55_CurrentcoordX
            , G55_CurrentcoordY, G55_CurrentcoordZ, G55_CurrentcoordA, G55_CurrentcoordB, G55_CurrentcoordC, G56_CurrentcoordX, G56_CurrentcoordY, G56_CurrentcoordZ, G56_CurrentcoordA
            , G56_CurrentcoordB, G56_CurrentcoordC, G57_CurrentcoordX, G57_CurrentcoordY, G57_CurrentcoordZ, G57_CurrentcoordA, G57_CurrentcoordB, G57_CurrentcoordC, G58_CurrentcoordX
            , G58_CurrentcoordY, G58_CurrentcoordZ, G58_CurrentcoordA, G58_CurrentcoordB, G58_CurrentcoordC, G59_CurrentcoordX, G59_CurrentcoordY, G59_CurrentcoordZ, G59_CurrentcoordA
            , G59_CurrentcoordB, G59_CurrentcoordC, G54_WorkoffsetX, G54_WorkoffsetY, G54_WorkoffsetZ, G54_WorkoffsetA, G54_WorkoffsetB, G54_WorkoffsetC, G55_WorkoffsetX, G55_WorkoffsetY
            , G55_WorkoffsetZ, G55_WorkoffsetA, G55_WorkoffsetB, G55_WorkoffsetC, G56_WorkoffsetX, G56_WorkoffsetY, G56_WorkoffsetZ, G56_WorkoffsetA, G56_WorkoffsetB, G56_WorkoffsetC, G57_WorkoffsetX
            , G57_WorkoffsetY, G57_WorkoffsetZ, G57_WorkoffsetA, G57_WorkoffsetB, G57_WorkoffsetC, G58_WorkoffsetX, G58_WorkoffsetY, G58_WorkoffsetZ, G58_WorkoffsetA, G58_WorkoffsetB, G58_WorkoffsetC
            , G59_WorkoffsetX, G59_WorkoffsetY, G59_WorkoffsetZ, G59_WorkoffsetA, G59_WorkoffsetB, G59_WorkoffsetC, TooloffsetZ, PWMspindle_PWMpin, PWMspindle_dirpin, PWMspindle_PWMfrequency
            , Stepdirspindle_Steppin, Stepdirspindle_Dirpin, Stepdirspindle_Stepsperrotation, Stepdirspindle_Acceleration, Spindle_Minvelocity, Spindle_Maxvelocity, Spindle_M3relaypin
            , Spindle_M4relaypin, Spindle_M3delayon, Spindle_M3delayoff, Spindle_M4delayon, Spindle_M4delayoff, Spindle_M7relaypin, Spindle_M8relaypin, Spindle_M7delayon, Spindle_M8delayon
            , Spindle_M9delay, Comm_buffer_size, CV_stopangledegrees, CV_Lookaheadlines, CV_Linearerrormax, CV_Cornererrormax, PositionDROsdigits, ToolZoffset1, ToolZoffset2, ToolZoffset3
            , ToolZoffset4, ToolZoffset5, ToolZoffset6, ToolZoffset7, ToolZoffset8, ToolZoffset9, ToolZoffset10, ToolZoffset11, ToolZoffset12, ToolZoffset13, ToolZoffset14, ToolZoffset15
            , ToolZoffset16, ToolZoffset17, ToolZoffset18, ToolZoffset19, ToolZoffset20, Newprofilename, CV_Linearadditionlenght, CV_Linearunifylength, THC_onpin, THC_uppin, THC_downpin
            , THC_min_height, THC_max_height, THC_feedrate, SafeZheight, XposDRO, YposDRO, ZposDRO, AposDRO, BposDRO, CposDRO, FRODRO, SRODRO, THC_ondelay, G73backoff, Xaxisstepport = 241
            , Xaxisdirport, Xaxislimitminusport, Xaxislimitplusport, Xaxishomeport, Yaxisstepport, Yaxisdirport, Yaxislimitminusport, Yaxislimitplusport, Yaxishomeport, Zaxisstepport
            , Zaxisdirport, Zaxislimitminusport, Zaxislimitplusport, Zaxishomeport, Aaxisstepport, Aaxisdirport, Aaxislimitminusport, Aaxislimitplusport, Aaxishomeport, Baxisstepport, Baxisdirport
            , Baxislimitminusport, Baxislimitplusport, Baxishomeport, Caxisstepport, Caxisdirport, Caxislimitminusport, Caxislimitplusport, Caxishomeport, Estopport, Probeport1, Indexport
            , Chargepumpport, THC_onport = 276, THC_upport, THC_downport, PWMspindle_PWMport, PWMspindle_dirport, Stepdirspindle_Stepport, Stepdirspindle_Dirport, Spindle_M3relayport
            , Spindle_M4relayport, Spindle_M7relayport, Spindle_M8relayport, MPGpinA, MPGportA, MPGpinB, MPGportB, Inputtrigger1pin, Inputtrigger1port, Inputtrigger1function, Inputtrigger2pin
            , Inputtrigger2port, Inputtrigger2function, Inputtrigger3pin, Inputtrigger3port, Inputtrigger3function, Inputtrigger4pin, Inputtrigger4port, Inputtrigger4function, Inputtrigger5pin
            , Inputtrigger5port, Inputtrigger5function, Inputtrigger6pin, Inputtrigger6port, Inputtrigger6function, Inputtrigger7pin, Inputtrigger7port, Inputtrigger7function, Inputtrigger8pin
            , Inputtrigger8port, Inputtrigger8function, Inputtrigger9pin, Inputtrigger9port, Inputtrigger9function, Inputtrigger10pin, Inputtrigger10port, Inputtrigger10function, Inputtrigger11pin
            , Inputtrigger11port, Inputtrigger11function, Inputtrigger12pin, Inputtrigger12port, Inputtrigger12function, Inputtrigger13pin, Inputtrigger13port, Inputtrigger13function
            , Inputtrigger14pin, Inputtrigger14port, Inputtrigger14function, Inputtrigger15pin, Inputtrigger15port, Inputtrigger15function, Inputtrigger16pin, Inputtrigger16port
            , Inputtrigger16function, Inputtrigger17pin, Inputtrigger17port, Inputtrigger17function, Inputtrigger18pin, Inputtrigger18port, Inputtrigger18function, Inputtrigger19pin
            , Inputtrigger19port, Inputtrigger19function, Inputtrigger20pin, Inputtrigger20port, Inputtrigger20function, Inputtrigger21pin, Inputtrigger21port, Inputtrigger21function
            , Inputtrigger22pin, Inputtrigger22port, Inputtrigger22function, Inputtrigger23pin, Inputtrigger23port, Inputtrigger23function, Inputtrigger24pin, Inputtrigger24port
            , Inputtrigger24function, Inputtrigger25pin, Inputtrigger25port, Inputtrigger25function, Inputtrigger26pin, Inputtrigger26port, Inputtrigger26function, Inputtrigger27pin
            , Inputtrigger27port, Inputtrigger27function, Inputtrigger28pin, Inputtrigger28port, Inputtrigger28function, Inputtrigger29pin, Inputtrigger29port, Inputtrigger29function
            , Inputtrigger30pin, Inputtrigger30port, Inputtrigger30function, Inputtrigger31pin, Inputtrigger31port, Inputtrigger31function, Inputtrigger32pin, Inputtrigger32port
            , Inputtrigger32function, Inputtrigger33pin, Inputtrigger33port, Inputtrigger33function, Inputtrigger34pin, Inputtrigger34port, Inputtrigger34function, Inputtrigger35pin
            , Inputtrigger35port, Inputtrigger35function, Inputtrigger36pin, Inputtrigger36port, Inputtrigger36function, Inputtrigger37pin, Inputtrigger37port, Inputtrigger37function
            , Inputtrigger38pin, Inputtrigger38port, Inputtrigger38function, Inputtrigger39pin, Inputtrigger39port, Inputtrigger39function, Inputtrigger40pin, Inputtrigger40port
            , Inputtrigger40function, Inputtrigger41pin, Inputtrigger41port, Inputtrigger41function, Inputtrigger42pin, Inputtrigger42port, Inputtrigger42function, Inputtrigger43pin
            , Inputtrigger43port, Inputtrigger43function, Inputtrigger44pin, Inputtrigger44port, Inputtrigger44function, Inputtrigger45pin, Inputtrigger45port, Inputtrigger45function
            , Inputtrigger46pin, Inputtrigger46port, Inputtrigger46function, Inputtrigger47pin, Inputtrigger47port, Inputtrigger47function, Inputtrigger48pin, Inputtrigger48port
            , Inputtrigger48function, MPGprescaler = 443, Analoginput1var, Analoginput2var, FROanalogchannelnumber = 447, FROanalogminpercent, FROanalogmaxpercent, SROanalogchannelnumber
            , SROanalogminpercent, SROanalogmaxpercent, JROanalogchannelnumber, JROanalogminpercent, JROanalogmaxpercent, MPGfilterconstant, MPGspeedmultiplier, PWMspindle_PWMmindutycycle
            , PWMspindle_PWMmaxdutycycle, Analogoutput1var, Analogoutput2var, SpindlePWM_analogoutputchannel, Xaxisenablepin, Xaxisenableport, Yaxisenablepin, Yaxisenableport, Zaxisenablepin
            , Zaxisenableport, Aaxisenablepin, Aaxisenableport, Baxisenablepin, Baxisenableport, Caxisenablepin, Caxisenableport, G92_offsetX = 500, G92_offsetY, G92_offsetZ, G92_offsetA
            , G92_offsetB, G92_offsetC, Hotkey_keycode1, Hotkey_function1, Hotkey_keycode2, Hotkey_function2, Hotkey_keycode3, Hotkey_function3, Hotkey_keycode4, Hotkey_function4, Hotkey_keycode5
            , Hotkey_function5, Hotkey_keycode6, Hotkey_function6, Hotkey_keycode7, Hotkey_function7, Hotkey_keycode8, Hotkey_function8, Hotkey_keycode9, Hotkey_function9, Hotkey_keycode10
            , Hotkey_function10, Hotkey_keycode11, Hotkey_function11, Hotkey_keycode12, Hotkey_function12, Hotkey_keycode13, Hotkey_function13, Hotkey_keycode14, Hotkey_function14, Hotkey_keycode15
            , Hotkey_function15, Hotkey_keycode16, Hotkey_function16, Hotkey_keycode17, Hotkey_function17, Hotkey_keycode18, Hotkey_function18, Hotkey_keycode19, Hotkey_function19, Hotkey_keycode20
            , Hotkey_function20, Hotkey_keycode21, Hotkey_function21, Hotkey_keycode22, Hotkey_function22, Hotkey_keycode23, Hotkey_function23, Hotkey_keycode24, Hotkey_function24, Hotkey_keycode25
            , Hotkey_function25, Hotkey_keycode26, Hotkey_function26, Hotkey_keycode27, Hotkey_function27, Hotkey_keycode28, Hotkey_function28, Hotkey_keycode29, Hotkey_function29, Hotkey_keycode30
            , Hotkey_function30, Hotkey_keycode31, Hotkey_function31, Hotkey_keycode32, Hotkey_function32, Hotkey_keycode33, Hotkey_function33, Hotkey_keycode34, Hotkey_function34, Hotkey_keycode35
            , Hotkey_function35, Hotkey_keycode36, Hotkey_function36, Hotkey_keycode37, Hotkey_function37, Hotkey_keycode38, Hotkey_function38, Hotkey_keycode39, Hotkey_function39, Hotkey_keycode40
            , Hotkey_function40, Hotkey_keycode41, Hotkey_function41, Hotkey_keycode42, Hotkey_function42, Hotkey_keycode43, Hotkey_function43, Hotkey_keycode44, Hotkey_function44, Hotkey_keycode45
            , Hotkey_function45, Hotkey_keycode46, Hotkey_function46, Hotkey_keycode47, Hotkey_function47, Hotkey_keycode48, Hotkey_function48, Hotkey_keycode49, Hotkey_function49, Hotkey_keycode50
            , Hotkey_function50, Hotkey_keycode51, Hotkey_function51, Hotkey_keycode52, Hotkey_function52, Hotkey_keycode53, Hotkey_function53, Hotkey_keycode54, Hotkey_function54, Hotkey_keycode55
            , Hotkey_function55, Hotkey_keycode56, Hotkey_function56, Hotkey_keycode57, Hotkey_function57, Hotkey_keycode58, Hotkey_function58, Hotkey_keycode59, Hotkey_function59, Hotkey_keycode60
            , Hotkey_function60, Hotkey_keycode61, Hotkey_function61, Hotkey_keycode62, Hotkey_function62, Hotkey_keycode63, Hotkey_function63, Hotkey_keycode64, Hotkey_function64, Hotkey_keycode65
            , Hotkey_function65, Hotkey_keycode66, Hotkey_function66, Hotkey_keycode67, Hotkey_function67, Hotkey_keycode68, Hotkey_function68, Hotkey_keycode69, Hotkey_function69, Hotkey_keycode70
            , Hotkey_function70, Hotkey_keycode71, Hotkey_function71, Hotkey_keycode72, Hotkey_function72, Hotkey_keycode73, Hotkey_function73, Hotkey_keycode74, Hotkey_function74, Hotkey_keycode75
            , Hotkey_function75, Hotkey_keycode76, Hotkey_function76, Hotkey_keycode77, Hotkey_function77, Hotkey_keycode78, Hotkey_function78, Hotkey_keycode79, Hotkey_function79, Hotkey_keycode80
            , Hotkey_function80, Hotkey_keycode81, Hotkey_function81, Hotkey_keycode82, Hotkey_function82, Hotkey_keycode83, Hotkey_function83, Hotkey_keycode84, Hotkey_function84, Hotkey_keycode85
            , Hotkey_function85, Hotkey_keycode86, Hotkey_function86, Hotkey_keycode87, Hotkey_function87, Hotkey_keycode88, Hotkey_function88, Hotkey_keycode89, Hotkey_function89, Hotkey_keycode90
            , Hotkey_function90, Hotkey_keycode91, Hotkey_function91, Hotkey_keycode92, Hotkey_function92, Hotkey_keycode93, Hotkey_function93, Hotkey_keycode94, Hotkey_function94
            , Hotkey_keycode95, Hotkey_function95, Hotkey_keycode96, Hotkey_function96, Outputtrigger1pin = 700, Outputtrigger1port, Outputtrigger1LED, Outputtrigger2pin, Outputtrigger2port
            , Outputtrigger2LED, Outputtrigger3pin, Outputtrigger3port, Outputtrigger3LED, Outputtrigger4pin, Outputtrigger4port, Outputtrigger4LED, Outputtrigger5pin, Outputtrigger5port
            , Outputtrigger5LED, Outputtrigger6pin, Outputtrigger6port, Outputtrigger6LED, Outputtrigger7pin, Outputtrigger7port, Outputtrigger7LED, Outputtrigger8pin, Outputtrigger8port
            , Outputtrigger8LED, Outputtrigger9pin, Outputtrigger9port, Outputtrigger9LED, Outputtrigger10pin, Outputtrigger10port, Outputtrigger10LED, Outputtrigger11pin, Outputtrigger11port
            , Outputtrigger11LED, Outputtrigger12pin, Outputtrigger12port, Outputtrigger12LED, Outputtrigger13pin, Outputtrigger13port, Outputtrigger13LED, Outputtrigger14pin, Outputtrigger14port
            , Outputtrigger14LED, Outputtrigger15pin, Outputtrigger15port, Outputtrigger15LED, Outputtrigger16pin, Outputtrigger16port, Outputtrigger16LED, Outputtrigger17pin, Outputtrigger17port
            , Outputtrigger17LED, Outputtrigger18pin, Outputtrigger18port, Outputtrigger18LED, Outputtrigger19pin, Outputtrigger19port, Outputtrigger19LED, Outputtrigger20pin, Outputtrigger20port
            , Outputtrigger20LED, Outputtrigger21pin, Outputtrigger21port, Outputtrigger21LED, Outputtrigger22pin, Outputtrigger22port, Outputtrigger22LED, Outputtrigger23pin, Outputtrigger23port
            , Outputtrigger23LED, Outputtrigger24pin, Outputtrigger24port, Outputtrigger24LED, Outputtrigger25pin, Outputtrigger25port, Outputtrigger25LED, Outputtrigger26pin, Outputtrigger26port
            , Outputtrigger26LED, Outputtrigger27pin, Outputtrigger27port, Outputtrigger27LED, Outputtrigger28pin, Outputtrigger28port, Outputtrigger28LED, Outputtrigger29pin, Outputtrigger29port
            , Outputtrigger29LED, Outputtrigger30pin, Outputtrigger30port, Outputtrigger30LED, Outputtrigger31pin, Outputtrigger31port, Outputtrigger31LED, Outputtrigger32pin, Outputtrigger32port
            , Outputtrigger32LED, Outputtrigger33pin, Outputtrigger33port, Outputtrigger33LED, Outputtrigger34pin, Outputtrigger34port, Outputtrigger34LED, Outputtrigger35pin, Outputtrigger35port
            , Outputtrigger35LED, Outputtrigger36pin, Outputtrigger36port, Outputtrigger36LED, Outputtrigger37pin, Outputtrigger37port, Outputtrigger37LED, Outputtrigger38pin, Outputtrigger38port
            , Outputtrigger38LED, Outputtrigger39pin, Outputtrigger39port, Outputtrigger39LED, Outputtrigger40pin, Outputtrigger40port, Outputtrigger40LED, Outputtrigger41pin, Outputtrigger41port
            , Outputtrigger41LED, Outputtrigger42pin, Outputtrigger42port, Outputtrigger42LED, Outputtrigger43pin, Outputtrigger43port, Outputtrigger43LED, Outputtrigger44pin, Outputtrigger44port
            , Outputtrigger44LED, Outputtrigger45pin, Outputtrigger45port, Outputtrigger45LED, Outputtrigger46pin, Outputtrigger46port, Outputtrigger46LED, Outputtrigger47pin, Outputtrigger47port
            , Outputtrigger47LED, Outputtrigger48pin, Outputtrigger48port, Outputtrigger48LED, EncoderApin = 852, EncoderAport, EncoderBpin, EncoderBport, CAM_Tooldia, CAM_Startdepth, CAM_Cutdepth
            , CAM_Cutperpass, CAM_SafeZ, CAM_Feedrate, CAM_Tooloverlap, CAM_Plungerate, EncoderPPR, CAM_Spindlespeed, Setnextlinefield, Setfeedrate, Actfeedrate, Setspindlespeed, Actspindlespeed
            , MachinecoordX, MachinecoordY, MachinecoordZ, MachinecoordA, MachinecoordB, MachinecoordC, Activemodal, IOmonitor_XPOS, IOmonitor_YPOS, IOmonitor_ZPOS, IOmonitor_APOS, IOmonitor_BPOS
            , IOmonitor_CPOS, Motionbuffer, Diagnostics_minX, Diagnostics_minY, Diagnostics_minZ, Diagnostics_maxX, Diagnostics_maxY, Diagnostics_maxZ, Diagnostics_sizeX, Diagnostics_sizeY
            , Diagnostics_sizeZ, Diagnostics_totalnumberofobjects, Diagnostics_Filename, Dwell_time, Active_toolnumber, Worktimer, Active_fixture, Profile_name, Licensed_to, Softwareversion
            , Firmwareversion, Hardwareversion, APIversion, Serialnumber, Devicetype, CAM_Statuslabel, Analog_inputvalue1, Analog_inputvalue2, Analog_outputvalue1, Analog_outputvalue2
            , Jogfeedrate, Laseroutputpin, Laseroutputport, ToolZoffset21 = 921, ToolZoffset22, ToolZoffset23, ToolZoffset24, ToolZoffset25, ToolZoffset26, ToolZoffset27, ToolZoffset28, ToolZoffset29
            , ToolZoffset30, ToolZoffset31, ToolZoffset32, ToolZoffset33, ToolZoffset34, ToolZoffset35, ToolZoffset36, ToolZoffset37, ToolZoffset38, ToolZoffset39, ToolZoffset40, ToolZoffset41
            , ToolZoffset42, ToolZoffset43, ToolZoffset44, ToolZoffset45, ToolZoffset46, ToolZoffset47, ToolZoffset48, ToolZoffset49, ToolZoffset50, ToolZoffset51, ToolZoffset52, ToolZoffset53
            , ToolZoffset54, ToolZoffset55, ToolZoffset56, ToolZoffset57, ToolZoffset58, ToolZoffset59, ToolZoffset60, ToolZoffset61, ToolZoffset62, ToolZoffset63, ToolZoffset64, ToolZoffset65
            , ToolZoffset66, ToolZoffset67, ToolZoffset68, ToolZoffset69, ToolZoffset70, ToolZoffset71, ToolZoffset72, ToolZoffset73, ToolZoffset74, ToolZoffset75, ToolZoffset76, ToolZoffset77
            , ToolZoffset78, ToolZoffset79, ToolZoffset80, ToolZoffset81, ToolZoffset82, ToolZoffset83, ToolZoffset84, ToolZoffset85, ToolZoffset86, ToolZoffset87, ToolZoffset88, ToolZoffset89
            , ToolZoffset90, ToolZoffset91, ToolZoffset92, ToolZoffset93, ToolZoffset94, ToolZoffset95, ToolZoffset96, MDIinput = 1000, THCAntidivevelocitypercentage = 2001, Analog_inputvalue3
            , Analog_inputvalue4, Analoginput3var, Analoginput4var, Analogoutput3var, Analogoutput4var, Analog_outputvalue3, Analog_outputvalue4, Plasmapieceheight, Probepin2, Probeport2
            , Pulleynumber, Pulleyratio, Digitize_numberofdigits, Digitize_proberadius, Digitize_filename, Digitize_numberofstoredpoints, Chargepump2pin, Chargepump2port, THCenableoutputpin
            , THCenableoutputport, Antidiveoutputpin, Antidiveoutputport, Antidownoutputpin, Antidownoutputport, JogStepDistance, Inputtrigger49pin = 2100, Inputtrigger49port, Inputtrigger49function
            , Inputtrigger50pin, Inputtrigger50port, Inputtrigger50function, Inputtrigger51pin, Inputtrigger51port, Inputtrigger51function, Inputtrigger52pin, Inputtrigger52port
            , Inputtrigger52function, Inputtrigger53pin, Inputtrigger53port, Inputtrigger53function, Inputtrigger54pin, Inputtrigger54port, Inputtrigger54function, Inputtrigger55pin
            , Inputtrigger55port, Inputtrigger55function, Inputtrigger56pin, Inputtrigger56port, Inputtrigger56function, Inputtrigger57pin, Inputtrigger57port, Inputtrigger57function
            , Inputtrigger58pin, Inputtrigger58port, Inputtrigger58function, Inputtrigger59pin, Inputtrigger59port, Inputtrigger59function, Inputtrigger60pin, Inputtrigger60port
            , Inputtrigger60function, Inputtrigger61pin, Inputtrigger61port, Inputtrigger61function, Inputtrigger62pin, Inputtrigger62port, Inputtrigger62function, Inputtrigger63pin
            , Inputtrigger63port, Inputtrigger63function, Inputtrigger64pin, Inputtrigger64port, Inputtrigger64function, Inputtrigger65pin, Inputtrigger65port, Inputtrigger65function
            , Inputtrigger66pin, Inputtrigger66port, Inputtrigger66function, Inputtrigger67pin, Inputtrigger67port, Inputtrigger67function, Inputtrigger68pin, Inputtrigger68port
            , Inputtrigger68function, Inputtrigger69pin, Inputtrigger69port, Inputtrigger69function, Inputtrigger70pin, Inputtrigger70port, Inputtrigger70function, Inputtrigger71pin
            , Inputtrigger71port, Inputtrigger71function, Inputtrigger72pin, Inputtrigger72port, Inputtrigger72function, Inputtrigger73pin, Inputtrigger73port, Inputtrigger73function
            , Inputtrigger74pin, Inputtrigger74port, Inputtrigger74function, Inputtrigger75pin, Inputtrigger75port, Inputtrigger75function, Inputtrigger76pin, Inputtrigger76port
            , Inputtrigger76function, Inputtrigger77pin, Inputtrigger77port, Inputtrigger77function, Inputtrigger78pin, Inputtrigger78port, Inputtrigger78function, Inputtrigger79pin
            , Inputtrigger79port, Inputtrigger79function, Inputtrigger80pin, Inputtrigger80port, Inputtrigger80function, Inputtrigger81pin, Inputtrigger81port, Inputtrigger81function
            , Inputtrigger82pin, Inputtrigger82port, Inputtrigger82function, Inputtrigger83pin, Inputtrigger83port, Inputtrigger83function, Inputtrigger84pin, Inputtrigger84port
            , Inputtrigger84function, Inputtrigger85pin, Inputtrigger85port, Inputtrigger85function, Inputtrigger86pin, Inputtrigger86port, Inputtrigger86function, Inputtrigger87pin
            , Inputtrigger87port, Inputtrigger87function, Inputtrigger88pin, Inputtrigger88port, Inputtrigger88function, Inputtrigger89pin, Inputtrigger89port, Inputtrigger89function
            , Inputtrigger90pin, Inputtrigger90port, Inputtrigger90function, Inputtrigger91pin, Inputtrigger91port, Inputtrigger91function, Inputtrigger92pin, Inputtrigger92port
            , Inputtrigger92function, Inputtrigger93pin, Inputtrigger93port, Inputtrigger93function, Inputtrigger94pin, Inputtrigger94port, Inputtrigger94function, Inputtrigger95pin
            , Inputtrigger95port, Inputtrigger95function, Inputtrigger96pin, Inputtrigger96port, Inputtrigger96function, Outputtrigger49pin = 2250, Outputtrigger49port, Outputtrigger49LED
            , Outputtrigger50pin, Outputtrigger50port, Outputtrigger50LED, Outputtrigger51pin, Outputtrigger51port, Outputtrigger51LED, Outputtrigger52pin, Outputtrigger52port, Outputtrigger52LED
            , Outputtrigger53pin, Outputtrigger53port, Outputtrigger53LED, Outputtrigger54pin, Outputtrigger54port, Outputtrigger54LED, Outputtrigger55pin, Outputtrigger55port, Outputtrigger55LED
            , Outputtrigger56pin, Outputtrigger56port, Outputtrigger56LED, Outputtrigger57pin, Outputtrigger57port, Outputtrigger57LED, Outputtrigger58pin, Outputtrigger58port, Outputtrigger58LED
            , Outputtrigger59pin, Outputtrigger59port, Outputtrigger59LED, Outputtrigger60pin, Outputtrigger60port, Outputtrigger60LED, Outputtrigger61pin, Outputtrigger61port, Outputtrigger61LED
            , Outputtrigger62pin, Outputtrigger62port, Outputtrigger62LED, Outputtrigger63pin, Outputtrigger63port, Outputtrigger63LED, Outputtrigger64pin, Outputtrigger64port, Outputtrigger64LED
            , Outputtrigger65pin, Outputtrigger65port, Outputtrigger65LED, Outputtrigger66pin, Outputtrigger66port, Outputtrigger66LED, Outputtrigger67pin, Outputtrigger67port, Outputtrigger67LED
            , Outputtrigger68pin, Outputtrigger68port, Outputtrigger68LED, Outputtrigger69pin, Outputtrigger69port, Outputtrigger69LED, Outputtrigger70pin, Outputtrigger70port, Outputtrigger70LED
            , Outputtrigger71pin, Outputtrigger71port, Outputtrigger71LED, Outputtrigger72pin, Outputtrigger72port, Outputtrigger72LED, Outputtrigger73pin, Outputtrigger73port, Outputtrigger73LED
            , Outputtrigger74pin, Outputtrigger74port, Outputtrigger74LED, Outputtrigger75pin, Outputtrigger75port, Outputtrigger75LED, Outputtrigger76pin, Outputtrigger76port, Outputtrigger76LED
            , Outputtrigger77pin, Outputtrigger77port, Outputtrigger77LED, Outputtrigger78pin, Outputtrigger78port, Outputtrigger78LED, Outputtrigger79pin, Outputtrigger79port, Outputtrigger79LED
            , Outputtrigger80pin, Outputtrigger80port, Outputtrigger80LED, Outputtrigger81pin, Outputtrigger81port, Outputtrigger81LED, Outputtrigger82pin, Outputtrigger82port, Outputtrigger82LED
            , Outputtrigger83pin, Outputtrigger83port, Outputtrigger83LED, Outputtrigger84pin, Outputtrigger84port, Outputtrigger84LED, Outputtrigger85pin, Outputtrigger85port, Outputtrigger85LED
            , Outputtrigger86pin, Outputtrigger86port, Outputtrigger86LED, Outputtrigger87pin, Outputtrigger87port, Outputtrigger87LED, Outputtrigger88pin, Outputtrigger88port, Outputtrigger88LED
            , Outputtrigger89pin, Outputtrigger89port, Outputtrigger89LED, Outputtrigger90pin, Outputtrigger90port, Outputtrigger90LED, Outputtrigger91pin, Outputtrigger91port, Outputtrigger91LED
            , Outputtrigger92pin, Outputtrigger92port, Outputtrigger92LED, Outputtrigger93pin, Outputtrigger93port, Outputtrigger93LED, Outputtrigger94pin, Outputtrigger94port, Outputtrigger94LED
            , Outputtrigger95pin, Outputtrigger95port, Outputtrigger95LED, Outputtrigger96pin, Outputtrigger96port, Outputtrigger96LED, AUXencoder1pinA = 2400, AUXencoder1portA, AUXencoder1pinB
            , AUXencoder1portB, AUXencoder2pinA, AUXencoder2portA, AUXencoder2pinB, AUXencoder2portB, AUXencoder3pinA, AUXencoder3portA, AUXencoder3pinB, AUXencoder3portB, AUXencoder4pinA
            , AUXencoder4portA, AUXencoder4pinB, AUXencoder4portB, AUXencoder5pinA, AUXencoder5portA, AUXencoder5pinB, AUXencoder5portB, AUXencoder6pinA, AUXencoder6portA, AUXencoder6pinB
            , AUXencoder6portB, AUXencoder1countsper, AUXencoder2countsper, AUXencoder3countsper, AUXencoder4countsper, AUXencoder5countsper, AUXencoder6countsper, AUXencoder1position
            , AUXencoder2position, AUXencoder3position, AUXencoder4position, AUXencoder5position, AUXencoder6position, SpindlePIDoutputpercentvalue, Arcradiustolerance, ScaleX, ScaleY, ScaleZ
            , ScaleA, ScaleB, ScaleC, DistanceToGoX, DistanceToGoY, DistanceToGoZ, DistanceToGoA, DistanceToGoB, DistanceToGoC, Feedrateoverridden, Spindlespeedoverridden, ToolDiameter1 = 2501
            , ToolDiameter2, ToolDiameter3, ToolDiameter4, ToolDiameter5, ToolDiameter6, ToolDiameter7, ToolDiameter8, ToolDiameter9, ToolDiameter10, ToolDiameter11, ToolDiameter12, ToolDiameter13
            , ToolDiameter14, ToolDiameter15, ToolDiameter16, ToolDiameter17, ToolDiameter18, ToolDiameter19, ToolDiameter20, ToolDiameter21, ToolDiameter22, ToolDiameter23, ToolDiameter24
            , ToolDiameter25, ToolDiameter26, ToolDiameter27, ToolDiameter28, ToolDiameter29, ToolDiameter30, ToolDiameter31, ToolDiameter32, ToolDiameter33, ToolDiameter34, ToolDiameter35
            , ToolDiameter36, ToolDiameter37, ToolDiameter38, ToolDiameter39, ToolDiameter40, ToolDiameter41, ToolDiameter42, ToolDiameter43, ToolDiameter44, ToolDiameter45, ToolDiameter46
            , ToolDiameter47, ToolDiameter48, ToolDiameter49, ToolDiameter50, ToolDiameter51, ToolDiameter52, ToolDiameter53, ToolDiameter54, ToolDiameter55, ToolDiameter56, ToolDiameter57
            , ToolDiameter58, ToolDiameter59, ToolDiameter60, ToolDiameter61, ToolDiameter62, ToolDiameter63, ToolDiameter64, ToolDiameter65, ToolDiameter66, ToolDiameter67, ToolDiameter68
            , ToolDiameter69, ToolDiameter70, ToolDiameter71, ToolDiameter72, ToolDiameter73, ToolDiameter74, ToolDiameter75, ToolDiameter76, ToolDiameter77, ToolDiameter78, ToolDiameter79
            , ToolDiameter80, ToolDiameter81, ToolDiameter82, ToolDiameter83, ToolDiameter84, ToolDiameter85, ToolDiameter86, ToolDiameter87, ToolDiameter88, ToolDiameter89, ToolDiameter90
            , ToolDiameter91, ToolDiameter92, ToolDiameter93, ToolDiameter94, ToolDiameter95, ToolDiameter96, Xenabledelay = 2600, Yenabledelay, Zenabledelay, Aenabledelay, Benabledelay
            , Cenabledelay, Xcurrenthilowpin, Ycurrenthilowpin, Zcurrenthilowpin, Acurrenthilowpin, Bcurrenthilowpin, Ccurrenthilowpin, Xcurrenthilowport, Ycurrenthilowport, Zcurrenthilowport
            , Acurrenthilowport, Bcurrenthilowport, Ccurrenthilowport, Debounce, DebounceTHC, DebounceHome, Xhomebackoff, Yhomebackoff, Zhomebackoff, Ahomebackoff, Bhomebackoff, Chomebackoff
            , Digitialsyncoutputpin1, Digitialsyncoutputport1, Digitialsyncoutputpin2, Digitialsyncoutputport2, Digitialsyncoutputpin3, Digitialsyncoutputport3, Digitialsyncoutputpin4
            , Digitialsyncoutputport4, Digitialsyncoutputpin5, Digitialsyncoutputport5, Digitialsyncoutputpin6, Digitialsyncoutputport6, Digitialsyncoutputpin7, Digitialsyncoutputport7
            , Digitialsyncoutputpin8, Digitialsyncoutputport8, Digitialsyncoutputpin9, Digitialsyncoutputport9, Digitialsyncoutputpin10, Digitialsyncoutputport10, Dragknifestopatangle
            , Dragkniferetractatangle, Dragkniferetractheight, Dragknifemovebackfeedrate, Dragknifepulloutfeedrate, Changetool, Laststatusmessage, Debounceprobe1, Debounceprobe2, CameraoffsetX
            , CameraoffsetY, CameraZheight, ProbeStatus = 2700, Axis1P, Axis2P, Axis3C, GageHeight, ProbeDiameter, FineDistance, Retract, SafeXYZ, FastFeed, FineFeed, ResultsPos1P, ResultsPos1N
            , ResultsSize1, ResultsCenter1, ResultsAngle, ResultsPos2P, ResultsPos2N, ResultsSize2, ResultsCenter2, MobileProbePosX, MobileProbePosY, MobileProbePosZ, MobileProbePosA, MobileProbePosB
            , MobileProbePosC, FixedProbePosX, FixedProbePosY, FixedProbePosZ, FixedProbePosA, FixedProbePosB, FixedProbePosC, SafeX, SafeY, SafeZ, SafeXYZLabel, OverrideProbeDia, TraverseSpeedLimit
            , BlowerPort, BlowerPin, BlowTime
      }

      #endregion
   }
}