﻿#pragma warning disable CS0649

namespace UCCNC
{
   public class Offsetcontrol
   {
      public int Number;
      public double TOZval;
      public double Wxval;
      public double Wyval;
      public double Wzval;
      public double Waval;
      public double Wbval;
      public double Wcval;
      public double Mxval;
      public double Myval;
      public double Mzval;
      public double Maval;
      public double Mbval;
      public double Mcval;
      public double Cxval;
      public double Cyval;
      public double Czval;
      public double Caval;
      public double Cbval;
      public double Ccval;
      public double G92xval;
      public double G92yval;
      public double G92zval;
      public double G92aval;
      public double G92bval;
      public double G92cval;
      //public UCCNC.Form1 mainform;

      public string fitnumseparator(string num) { return ""; }
      public void setnewTOZ(double val) { }
      public void setnewG92x(double val) { }
      public void setnewG92y(double val) { }
      public void setnewG92z(double val) { }
      public void setnewG92a(double val) { }
      public void setnewG92b(double val) { }
      public void setnewG92c(double val) { }
      public void setnewWx(double val) { }
      public void setnewWy(double val) { }
      public void setnewWz(double val) { }
      public void setnewWa(double val) { }
      public void setnewWb(double val) { }
      public void setnewWc(double val) { }
      public void newCxinput(double val) { }
      public void newCyinput(double val) { }
      public void newCzinput(double val) { }
      public void newCainput(double val) { }
      public void newCbinput(double val) { }
      public void newCcinput(double val) { }
      public void setnewCx(double val) { }
      public void setnewCy(double val) { }
      public void setnewCz(double val) { }
      public void setnewCa(double val) { }
      public void setnewCb(double val) { }
      public void setnewCc(double val) { }
   }
}