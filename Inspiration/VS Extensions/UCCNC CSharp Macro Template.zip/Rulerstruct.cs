﻿#pragma warning disable CS0649

namespace UCCNC
{
   public struct Rulerstruct
   {
      public float Heights;
      public int ImageXsize;
      public int ImageYsize;
      public int ImageZsize;
      public float ImageXsize_diffX;
      public float ImageXsize_diffY;
      public float ImageYsize_diffX;
      public float ImageYsize_diffY;
      public float ImageZsize_diffX;
      public float ImageZsize_diffY;
      public float ImageXsize_lenght;
      public float ImageYsize_lenght;
      public float ImageZsize_lenght;
      public float ImageXsize_arany;
      public float ImageYsize_arany;
      public float ImageZsize_arany;
      public int ImageXstart;
      public float ImageXstart_diffX;
      public float ImageXstart_diffY;
      public float ImageXstart_length;
      public float ImageXstart_arany;
      public int ImageXend;
      public float ImageXend_diffX;
      public float ImageXend_diffY;
      public float ImageXend_length;
      public float ImageXend_arany;
      public int ImageYstart;
      public float ImageYstart_diffX;
      public float ImageYstart_diffY;
      public float ImageYstart_length;
      public float ImageYstart_arany;
      public int ImageYend;
      public float ImageYend_diffX;
      public float ImageYend_diffY;
      public float ImageYend_length;
      public float ImageYend_arany;
      public int ImageZstart;
      public float ImageZstart_diffX;
      public float ImageZstart_diffY;
      public float ImageZstart_length;
      public float ImageZstart_arany;
      public int ImageZend;
      public float ImageZend_diffX;
      public float ImageZend_diffY;
      public float ImageZend_length;
      public float ImageZend_arany;
   }
}