﻿#pragma warning disable CS0649

namespace UCCNC
{
   public struct Substackstruct
   {
      public int substartID;
      public int subreturnID;
      public int numberofcalls;
      public int callcounter;
   }
}