﻿#pragma warning disable CS0649

namespace Plugininterface.Datatypes
{
   public struct Tooltablestruct
   {
      public int Toolnumber;
      public int Slot;
      public double OffsetZ;
      public double Dia;
      public string Description;
      public string Type;
      public string Material;
   }
}