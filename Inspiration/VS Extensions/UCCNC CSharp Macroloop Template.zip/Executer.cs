﻿#pragma warning disable CS0649

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace UCCNC
{
   public class Executer
   {
      public static int substackdepth;
      public static int ivarssize;
      public static int LEDssize;

      //public Executer(UCCNC.Form1 mainform) { }
      public Executer() { }

      public UCCNC.Rulerstruct Rulerproperties;
      public double LaserimageStartX;
      public double LaserimageStartY;
      public double Overrundistance;
      public float laserimageDiffX;
      public float laserimageDiffY;
      public double LaserimageWidth;
      public double LaserimageHeight;
      public int Laserimagenumber;
      public int actfeedratemode;
      public double[] Modalcodes;
      public int acttooloffsetnumber;
      public int acttooloffsetmodal;
      public bool GUIdisabled;
      public int[] Ismacrorun;
      public bool CycleStopped;
      public bool Filereloadcommand;
      //public UCCNC.Tooltabledetailed Tooltable;
      //public UCCNC.Rcomperrorform RcomperrForm;
      public double ArcstartposX;
      public double ArcstartposY;
      //public UCCNC.Rcompensator DC;
      public bool G68active;
      public double rotX;
      public double rotY;
      public double rotAngle;
      public double scaleX;
      public double scaleY;
      public double scaleZ;
      public double scaleA;
      public double scaleB;
      public double scaleC;
      public bool tabbing;
      //public List<UCCNC.Executer.Axesposition> Probepoints;
      public int Fieldenteredscreennumber;
      public TimeSpan Totaltime;
      public TimeSpan M3time;
      public TimeSpan M4time;
      public TimeSpan Cyclestime;
      public Stopwatch Totaltimestopwatch;
      public Stopwatch M3timestopwatch;
      public Stopwatch M4timestopwatch;
      public Stopwatch Cyclestimestopwatch;
      public int TotalM3s;
      public int TotalM4s;
      public int TotalM7s;
      public int TotalM8s;
      public bool hotkeysenabled;
      public string OperatorPassword;
      public bool Lastactionwasstepjog;
      public double Xstepjogpos;
      public bool Call1000;
      public bool THCvirtualARCON;
      public bool THCvirtualUP;
      public bool THCvirtualDOWN;
      //public UCCNC.Questionbox Questionbox1;
      public bool didinitialmovement;
      public bool IsHoming;
      public int rememberjogmode;
      public bool[] looprun;
      public string laststatusmessage;
      public bool fileloading;
      public bool destructed;
      public bool feedholdbuttonstate;
      public bool Isfeedhold;
      public bool stepjoggoing;
      public int MDInumber;
      public bool calledfromscreen;
      public int homi;
      public bool dohoming;
      public bool constructmacro;
      public bool destructmacro;
      //public UCCNC.IniReader profile;
      public bool[] ISenableLEDset;
      public int AnIn1;
      public int AnIn2;
      public int AnIn3;
      public int AnIn4;
      public int AnOut1;
      public int AnOut2;
      public int AnOut3;
      public int AnOut4;
      public int MPGaxis;
      public int MPGmode;
      public double[] ivars;
      public int actualdistmode;
      public bool Isabs;
      public List<UCCNC.Substackstruct> Substack;
      public List<int> SubstackR;
      public bool MDIstopped;
      public int actualmodal;
      public int prevmodal;
      public double? MachposQ;
      public double? MachposK;
      public double? PeckZ;
      //public UCCNC.Runfromhereform RFH;
      public bool doinitialmovement;
      public bool setnextlinepressed;
      public double eWzval;
      public double eTOZval;
      public bool jogXpbuttonpressed;
      public bool jogXmbuttonpressed;
      public bool jogYpbuttonpressed;
      public bool jogYmbuttonpressed;
      public bool jogZpbuttonpressed;
      public bool jogZmbuttonpressed;
      public bool jogApbuttonpressed;
      public bool jogAmbuttonpressed;
      public bool jogBpbuttonpressed;
      public bool jogBmbuttonpressed;
      public bool jogCpbuttonpressed;
      public bool jogCmbuttonpressed;
      public int grabbedkey;
      public bool macrocall;
      public bool macroloopcall;
      public bool showmachinecoords;
      public bool Loadimages;
      public bool Loadmainscreen;
      public bool Loadjogscreen;
      public int[] LEDstates;
      public bool[] Buttonstates;
      public bool Limitsoverridemode;
      public bool Offlinemode;
      public int jogmode;
      public double jogsteprate;
      public bool Xhomed;
      public bool Yhomed;
      public bool Zhomed;
      public bool Ahomed;
      public bool Bhomed;
      public bool Chomed;
      public double JogFeedrate;
      public int Currenttool;
      public bool macrostop;
      public string newstatusmessage;
      public string digitsformat;
      public string actualprofilename;
      public double Wx;
      public double Wy;
      public double Wz;
      public double Wa;
      public double Wb;
      public double Wc;
      public double Oz;
      public UCCNC.Offsetcontrol ofc;
      public UC100.Stat UCstat;
      public UC100.Stat Sstat;
      public UC100.Stat GetlineUCstat;
      public UC100.Stat SetvarUCstat;
      public double actualfeedoverride;
      public double Xstepsize;
      public double Ystepsize;
      public double Zstepsize;
      public double Astepsize;
      public double Bstepsize;
      public double Cstepsize;
      public double actualSS;
      public long currentOutput;
      public double dwelltime;
      public bool exit;
      public bool joghidden;
      public bool M3on;
      public bool M4on;
      public bool M7on;
      public bool M8on;
      public bool MDIgo;
      public double lastfeed;
      public bool Estopin;
      public bool go;
      public bool stopped;
      public UCCNC.Form1 mainform;
      public int startobjectnumber;
      public BackgroundWorker cyclerunner;
      public BackgroundWorker MDIrunner;
      public int gcodelinenumber;
      public bool theAutozero;
      public int actplane;
      public int actcannedreturnlevel;

      public string TextQuestion(string Questiontext) { return ""; }
      public double Question(string Questiontext) { return 0; }
      public void Virtual_THCarcon(bool Ison) { }
      public void Virtual_THCup(bool Ison) { }
      public void Virtual_THCdown(bool Ison) { }
      public void OperatorLock() { }
      public void Showstatistics() { }
      public void Jograpiddisable(bool disable) { }
      public void Jogdisable(bool disable) { }
      public int Showplugin(string pluginfilename) { return 0; }
      public int Configplugin(string pluginfilename) { return 0; }
      public ushort[] GetAllModbusArray() { return new ushort[0]; }
      public bool SetModbusregister(int Registernumber, ushort Value) { return false; }
      public bool SetModbusregisters(int Startregister, ushort[] Values) { return false; }
      public bool GetModbusregister(int Registernumber, ushort Value) { return false; }
      public bool GetModbusregisters(int Startregister, int Registercount, ushort[] Values) { return false; }
      public void WriteModbusString(string Str, int Startregister, bool HightoLowByteorder) { }
      public bool IsOdd(int value) { return false; }
      public void Showspindlepulleys() { }
      public void Startdigitizing() { }
      public void Stopdigitizing() { }
      public void StopdigitizingDelegated() { }
      public void Setdigitizefilename() { }
      public double Getvar(int varnum) { return 0; }
      public void Setvar(double value, int varnum) { }
      public void Toggletabbing() { }
      public void Tabbingoff() { }
      public void Tabbingon() { }
      public void JogfeedResetto100percent() { }
      public void FROResetto100percent() { }
      public void SROResetto100percent() { }
      public void M1optionalstopon() { }
      public void M1optionalstopoff() { }
      public void ToggleM1optionalstop() { }
      public void Deleteallprecompiledmacros() { }
      public void Precompileallmacros() { }
      public void Createinternalmacroslist() { }
      public Object Informplugin(string Pluginfilename, Object Message) { return new Object(); }
      public void Informplugins(Object Message) { }
      public void Setupsliders() { }
      public void OpenSpindlePIDsetupwindow() { }
      public void RemoveRunfromhere() { }
      public void CoordsTransform(double Xval, double Yval, double Zval, double Aval, double Bval, double Cval) { }
      public void CoordsTransformABS(double Xval, double Yval, double Zval, double Aval, double Bval, double Cval, bool Xmove, bool Ymove, bool Zmove, bool Amove, bool Bmove, bool Cmove) { }
      public void CoordsTransformInv(double? Xval, double? Yval, double? Zval, double? Aval, double? Bval, double? Cval) { }
      public void ScalevectorInv(double? Xval, double? Yval, double? Zval, double? Aval, double? Bval, double? Cval) { }
      public void Rotatevector(double Xval, double Yval) { }
      public void RotatevectorInv(double? Xval, double? Yval) { }
      public void ShowTooltable() { }
      public void ShowRcomperrorlist() { }
      public string Getgcodelinetext(int rownumber) { return ""; }
      public string Getcurrgcodelinetext() { return ""; }
      public int Getcurrentgcodelinenumber() { return 0; }
      public int Ismacrorunning(int macronumber) { return 0; }
      public bool IsGUIdisabled() { return false; }
      public void DisableGUI(bool disable) { }
      public bool Isfillshown() { return false; }
      public List<Plugininterface.Datatypes.Layerdatastruct> Getlayerslist(bool isAS3) { return new List<Plugininterface.Datatypes.Layerdatastruct>(); }
      public void Getmainwindowproperties(Point Windowlocation, Size Windowsize) { }
      public Plugininterface.Datatypes.Tooltablestruct[] Gettooltabledata() { return new Plugininterface.Datatypes.Tooltablestruct[0]; }
      public double Getactualmodalcode(int groupnumber) { return 0; }
      public bool Isresetactive(bool Showresetmessage) { return false; }
      public void Disableproberadius(bool Disable) { }
      public void OKwindow() { }
      public void Newtoolselection(double val) { }
      public void Changeselectedtool() { }
      public void ChangeSetFeedRateDRO_event(double val) { }
      public void ChangeSetSpindleSpeedDRO_event(double val) { }
      public void Getcutdistancestatistics(double X, double Y, double Z, double A, double B, double C, double CutX, double CutY, double CutZ, double CutA, double CutB, double CutC) { }
      public void Setlaserimage(Image img, double StartX, double StartY, double Width, double Height, double Overrundistance) { }
      public void Toggletoolpathdimensionsvisibility() { }
      public void Toolpathdimensionsvisibilityon() { }
      public void Toolpathdimensionsvisibilityoff() { }
      public bool IsValidPortPin(int port, int pin, bool isoutput) { return false; }
      public void physicalzeroaxis(int axisnumber, double value) { }
      public void ClearM0M1M60LEDs() { }
      public void rewindfile() { }
      public void writejobproperties() { }
      public string fnum(double Value) { return ""; }
      public string fnum4digits(double Value) { return ""; }
      public void Setoutpin(int portnumber, int pinnumber) { }
      public void Clroutpin(int portnumber, int pinnumber) { }
      public int GetUCpin(int Port, int Pin, bool Isoutput) { return 0; }
      public int getUCpinfromportsandpinslabels(int portlabel, int pinlabel, bool Isoutput) { return 0; }
      public int SetOutBit(int bitnumber) { return 0; }
      public int ClrOutBit(int bitnumber) { return 0; }
      public void editGcodefile() { }
      public bool Checkifinposition(double Xtomove, double Ytomove, double Ztomove) { return false; }
      public bool Checkiffullcircle(double Xtomove, double Ytomove, double Ztomove) { return false; }
      public void AddLinear(double XX, double YY, double ZZ, double AA, double BB, double CC, double Feed, int ID) { }
      public void AddLinearABS(double XX, double YY, double ZZ, double AA, double BB, double CC, bool Xmove, bool Ymove, bool Zmove, bool Amove, bool Bmove, bool Cmove, double Feed, int ID) { }
      public void AddCircular(double XX, double YY, double ZZ, double rXX, double rYY, bool dir, double Feed, int Plane, int ID, int NextID) { }
      public void AddSyncMoveP(double? XX, double? ZZ, double PP, double? QQ, int ID) { }
      public void AddRigidTappingMove(double ZZ, double KK, bool DIR, int ID) { }
      public void AddDummy(int ID) { }
      public void decrypt(string serialfilename, string name, string serial) { }
      public void Setaxishomestate(int axis, bool Ishomed) { }
      public void Derefallaxeshomes() { }
      public void SetJRO() { }
      public void SetupEncodersettings() { }
      public void SwitchMPG() { }
      public void MPGaxisselect(int axisnumber) { }
      public void MPGmodeselect(int mode) { }
      public void Takecareofcheckboxes(int Checkboxnumber, bool IsOn) { }
      public void ClearG92offset() { }
      public void Inputlabelvaluechangedint(int box, int val, bool Slider) { }
      public void Inputlabelvaluechanged(string box, string val, bool Slider) { }
      public void Setnewselectedrownumberint(int val) { }
      public void Setnewselectedrownumber(string val) { }
      public void ChangeSSODROvalue(string val) { }
      public void ChangeFRODROvalue(string val) { }
      public void ChangeaxisDROvalue(int axisnumber, string val) { }
      public void offsetcurrentpos(int offsetnumber) { }
      public void clearworkoffset(int offsetnumber) { }
      public void cleartooloffset() { }
      public void Setversiontext() { }
      public void Setscreennumformat(int Digitplaces) { }
      public void Zeroworktimer() { }
      public long Getcodetotalruntimemsec() { return 0; }
      public void Calibrateaxis(int Axisnumber) { }
      public void Sethotkey(int keylabelnumber) { }
      public void Setfunctionkey(int keylabelnumber) { }
      public void SetLEDkey(int keylabelnumber) { }
      public void Loadfile(string filename) { }
      public void Reloadfile() { }
      public bool IsLoading() { return false; }
      public bool IsSoftlimit() { return false; }
      public bool IsMoving() { return false; }
      public bool IsMovingTHC() { return false; }
      public bool IsMovingFast() { return false; }
      public bool IsMovingforHomeing() { return false; }
      public void Setcurrenttool(int toolnumber) { }
      public int Getcurrenttool() { return 0; }
      public int Getnewtool() { return 0; }
      public double GetXmachpos() { return 0; }
      public double GetYmachpos() { return 0; }
      public double GetZmachpos() { return 0; }
      public double GetAmachpos() { return 0; }
      public double GetBmachpos() { return 0; }
      public double GetCmachpos() { return 0; }
      public double GetXpos() { return 0; }
      public double GetYpos() { return 0; }
      public double GetZpos() { return 0; }
      public double GetApos() { return 0; }
      public double GetBpos() { return 0; }
      public double GetCpos() { return 0; }
      public void StopWithDeccel() { }
      public void Stop() { }
      public void Wait(int szam) { }
      public void CodesyncCallfromplugin(string Macrocode) { }
      public void Codesync(string thecode) { }
      public void Code(string Macrocode) { }
      public void CodelistCallfromplugin(List<string> Macrocodelist) { }
      public void Codelist(List<string> Macrocodelist) { }
      public void Setofflinemode(bool setoffline) { }
      public bool Ismacrostopped() { return false; }
      public bool GetLED(int LEDnumber) { return false; }
      public void SetLED(bool val, int LEDnumber) { }
      public void Pluginshowup(string Pluginfilename) { }
      public int Getanaloginput(int channel) { return 0; }
      public int Getanalogoutput(int channel) { return 0; }
      public void Swapaxis(int axis1, int axis2) { }
      public void Resetswapaxis() { }
      public void Slaveaxis(int masteraxis, int slaveaxis) { }
      public List<UCCNC.Functionproperties> Getbuttonsdescriptions() { return new List<UCCNC.Functionproperties>(); }
      public List<UCCNC.Functionproperties> GetLEDsdescriptions() { return new List<UCCNC.Functionproperties>(); }
      public void Callbutton_fromscreen(int bn) { }
      public void Callbutton_fromscreen_thr(int buttonnumber) { }
      public void Callbutton(int bn) { }
      public void Callbutton_directly(int buttonnumber) { }
      public void Writekey(string section, string key, string value) { }
      public string Readkey(string section, string key, string defaultvalue) { return ""; }
      public void Setbuttonstate(int buttonnumber, bool Ison) { }
      public void RestartApp(string args) { }
      public void Stopjogging() { }
      public void AddDwell(double time, int ID) { }
      public UCCNC.Allvarstruct GetAllmacrovars(UCCNC.Allvarstruct vars) { return new UCCNC.Allvarstruct(); }
      public string Getgcodefilename() { return ""; }
      public void SetRotate(double Rx, double Ry, double Rangle) { }
      public void GetRotate(double Rx, double Ry, double Angle) { }
      public void SetScale(double? ScX, double? ScY, double? ScZ, double? ScA, double? ScB, double? ScC) { }
      public void SetScaleX(double ScX) { }
      public void SetScaleY(double ScY) { }
      public void SetScaleZ(double ScZ) { }
      public void SetScaleA(double ScA) { }
      public void SetScaleB(double ScB) { }
      public void SetScaleC(double ScC) { }
      public double GetXscale() { return 0; }
      public double GetYscale() { return 0; }
      public double GetZscale() { return 0; }
      public double GetAscale() { return 0; }
      public double GetBscale() { return 0; }
      public double GetCscale() { return 0; }
      public int GetPlane() { return 0; }
      public void SetPlane(int plane, int ID) { }
      public void SetPathmode(int mode, int ID) { }
      public int GetPathmode() { return 0; }
      public void SetCannedreturnlevel(int level, int ID) { }
      public int GetCannedreturnlevel() { return 0; }
      public void Doaxiscalibration(int axisnumber) { }
      public void Activateoffset(int offsetnumber) { }
      public void Loadoffset(UCCNC.Gstructloadoffset Gt) { }
      public void LimitsOverride() { }
      public void ClearStatusmessage() { }
      public void AddStatusmessage(string newmessage) { }
      public void goOffline() { }
      public void goOnline() { }
      public void doprobe() { }
      public void zeroaxis(int axisnumber, double value) { }
      public void Showreseterror() { }
      public void Showstuckedjogkeyerror() { }
      public void Showoutoflimitserror() { }
      public void Showerrormessage(string windowmessage, string statusmessage, bool Isdialog) { }
      public void Showerrormessagesync(string windowmessage, string statusmessage, bool Isdialog) { }
      public void Setpulley() { }
      public void Setspindlespeed(double setspeed) { }
      public void Gotozero() { }
      //public bool executeMDIline(UCCNC.Gobject ggc) { return false; }
      //public bool executeMacroline(UCCNC.Gobject ggc) { return false; }
      public void Getactualoffset() { }
      public void Initfeed() { }
      public int getstoppedlinenumber() { return 0; }
      public double getcurrentfeedrate() { return 0; }
      public int getstoppedobjectnumber(int linenumber) { return 0; }
      public int getfirstobjectnumberinrow(int linenumber) { return 0; }
      public int getlastobjectnumberinrow(int linenumber) { return 0; }
      public int getbuffer() { return 0; }
      public void DospinCW() { }
      public void DospinCWND() { }
      public void DospinCCW() { }
      public void DospinCCWND() { }
      public void Stopspin() { }
      public void StopspinND() { }
      public void Miston() { }
      public void MistonND() { }
      public void Floodon() { }
      public void FloodonND() { }
      public void Stopcoolant() { }
      public void StopcoolantND() { }
      public void StopmistND() { }
      public void StopfloodND() { }
      public double fitnumseparator(string szam) { return 0; }
      public string fitnumseparatorstr(string num) { return ""; }
      public void Togglesoftlimits() { }
      public void softlimitson() { }
      public void softlimitsoff() { }
      public void Setsoftlimits(bool enable) { }
      public void ToggleTHC() { }
      public void THCon() { }
      public void THCoff() { }
      public void SetTHC(bool enable) { }
      public void ToggleTHCantidive() { }
      public void THCantidiveon() { }
      public void THCantidiveoff() { }
      public void SetTHCantidive(bool enable) { }
      public void ToggleTHCantidown() { }
      public void THCantidownon() { }
      public void THCantidownoff() { }
      public void SetTHCantidown(bool enable) { }
      public void ToggleTHCdelay() { }
      public void THCdelayon() { }
      public void THCdelayoff() { }
      public void SetTHCdelay(bool enable) { }
      public void Safeprobeon() { }
      public void Safeprobeoff() { }
      public void Togglesafeprobe() { }
      public void Jogsafeprobeon() { }
      public void Jogsafeprobeoff() { }
      public void Togglejogsafeprobe() { }
      public void GetCyclestartinitialcoordinates(int line) { }
      public void updatelaserprogress(int state) { }
      public bool CheckifHomed() { return false; }
      public void Cyclestart() { }
      public void Runsingleline() { }
      public void Togglefeedhold() { }
      public void Feedholdon() { }
      public void Feedholdoff() { }
      public void CycleStart(int startobjectnumber, int endobjectnumber, bool singlerun) { }
      public void CycleStopwithDeccel() { }
      public void setjograte(double val) { }
      public void increasejograte() { }
      public void decreasejograte() { }
      public void changejograte(int jogselection) { }
      public void changejogmode(int jogmode) { }
      public void stepjog(int axis, bool directionnegative, int currjogmode) { }
      public void DoHomeAll(bool isG28) { }
      public void Dohomeallthread() { }
      public void DoSingleHome(int Axis, double speedup, double speeddown, bool dir, bool Autozero, bool isG28, bool isAllhomesequence) { }
   }
}