﻿#pragma warning disable CS0649

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows.Forms;

namespace UCCNC
{
   public class Form1 : Form
   {
      public static bool ApplicationIsActivated() { return false; }
      public static int GetKeyboardState(Byte[] keystate) { return 0; }
      public static double[] convertFloatsToDoubles(float[] input) { return new double[0]; }

      public BackgroundWorker loadfileworker;
      public PictureBox ownprogressbar;
      public Label label10;
      public Panel jogcontrol1;
      public Timer timer2;
      public Panel starthiderpanel;
      //public OpenTK.GLControl glControl2;
      //public OpenTK.GLControl glControl3;
      //public OpenTK.GLControl glControl1;
      public Panel panel1;
      public Panel Savesettingspanel;
      public Label Savesettingslabel;
      public string Softwareversion;
      //public UCCNC.WebCAM camera;
      public ToolTip toolTip;
      public bool Refreshtoolpathdisabledstate;
      public bool changingvertex;
      public bool loadingvertex;
      public float knifeangle;
      public bool eFROover100;
      public bool eFROunder100;
      public bool eSROover100;
      public bool eSROunder100;
      public UInt32 colorBufferId;
      public UInt32 DcolorBufferId;
      public float[] Dvertexbuffer;
      //public OpenTK.Vector3[] Dcolortablepath;
      public bool Startedup;
      public bool Savingsettingsnow;
      public bool Saveonclosingnow;
      public bool Screenloading;
      public int Screencallsumnum;
      public int Screencalls;
      public bool Coordsupdate;
      public bool Applyingsettingsnow;
      public bool DonotenterDROonce;
      //public UCCNC.Spindlepulleys Pulleys;
      public bool jogdisabled;
      public bool RestartApp;
      public string RestartArgs;
      //public UCCNC.Compressionmethod GLavailabelcompressionmethod;
      //public UCCNC.Macroloopconfig Macroloopconfigwindow;
      //public UCCNC.Macroloop[] Macroloops;
      public List<string> messagequeqe;
      public int maxlayernumber;
      public string screensetfilename;
      public double minobjsize;
      public double minlistsizeX;
      public double minlistsizeY;
      public double mincomboboxsizeX;
      public int currentclickedlayer;
      public double OpenGLversion;
      public bool IsopenGLversionOK;
      public bool UseARB_vertex_buffer_object;
      public bool IsopenGL_anisotropic_supported;
      public bool IsopenGL_nonpoweroftwo_supported;
      //public UCCNC.Screeneditor se;
      public bool Isscreenedit;
      //public UCCNC.Playback Audio;
      public int jogscreensizeX;
      public int jogscreensizeY;
      public int mainscreensizeX;
      public int mainscreensizeY;
      public int showrow;
      //public UCCNC.Comboselector Combo;
      public int maxtabnum;
      //public UCCNC.GUIevents mainGUIevents;
      public List<UCCNC.Functionproperties> Buttonsdetails;
      public List<UCCNC.Functionproperties> LEDsdetails;
      public bool Doshutdown;
      public bool Pluginsloaded;
      public bool Pluginsstarted;
      //public List<UCCNC.Pluginthread> Pthread;
      //public UCCNC.Plugins UCplugins;
      public bool Didmainformpreparation;
      public bool Didjogbuildpreparation;
      public int splashscreennumber;
      public bool jogbuilt;
      public bool mainbuilt;
      public bool firststart;
      public bool startscreenerror;
      //public UCCNC.UCCAMinterface cam;
      public int maxlabelnum;
      public int checkboxnum;
      public int comboboxnum;
      public int labelnum;
      public bool[] keyboardkeys;
      public bool[] keysstatic;
      public bool[] ekeysstatic;
      public bool demomode;
      public bool forceclose;
      public int userselecteddevice;
      //public UC100.DeviceType userselecteddevtype;
      //public UCCNC.Portandpindef[] actpindef;
      //public UCCNC.Analogports analogdef;
      public int maxport;
      public int maxpin;
      public int maxAnaInport;
      public int maxAnaOutport;
      public bool firstcycleUC300demooutpinsfix;
      //public UCCNC.Inputtrigger intrig;
      //public UCCNC.Hotkeytrigger hottrig;
      //public UCCNC.Outputtrigger outtrig;
      public bool hottriggerfirsttime;
      public bool xjogging;
      public bool yjogging;
      public bool zjogging;
      public bool ajogging;
      public bool bjogging;
      public bool cjogging;
      public bool anyDROinfocus;
      public UCCNC.Systemmessages MSG;
      public bool Connectionerrorhappened;
      public int m30line;
      public Stopwatch stopwatch;
      public Stopwatch sysruntime;
      public bool hidesetup;
      public bool ehidesetup;
      public ListBox Statuslistbox;
      //public UCCNC.Sumoffsetcontrol sumoffsetcontrol1;
      //public UCCNC.axisDROcontrol AxisDRO;
      //public UCCNC.UC100setup UCsetup;
      public bool isclosing;
      public bool disablelayerchange;
      public bool buttonbuildends;
      public int screenbuilds;
      public int jogtab;
      //public UCCNC.UC100IOmonitor UC100IOmonitor1;
      //public UCCNC.resetbuttoncontrol resetbuttoncontrol1;
      //public UCCNC.Profilesetup ProfileControl1;
      public int actuallayer;
      public int toolpathlayer;
      public UCCNC.AS3interfaceClass AS3;
      public UCCNC.AS3interfaceClass AS3jog;
      public string[] arguments;
      //public UCCNC.Screenbuilder Screenbuildinstance;
      //public UCCNC.Loadsavesettings LS;
      public bool boxselected;
      public float[] vertexbuffer;
      public float[] arrowvertexbuffer;
      public float[] conevertexbuffer;
      public int cursorcolor;
      public int screenbackcolor;
      //public UCCNC.Makedrawing mk;
      public bool keyjogon;
      //public UCCNC.Mymessagebox mg;
      //public UCCNC.GInterpreter Gpret;
      //public UCCNC.GInterpreter Mpret;
      public double xp;
      public double yp;
      public double zp;
      public double ap;
      public double bp;
      public double cp;
      public double xpd;
      public double ypd;
      public double zpd;
      public double apd;
      public double bpd;
      public double cpd;
      public bool havetoupdatescreen;
      public bool codebeginning;
      public int actuallinetoexecute;
      public UC100.Stat UCstat;
      public long Inputpins;
      //public UC100.SPSetting SPset;
      public UCCNC.Executer exec;
      public int updatewaittime;
      public int viewerupdate;
      public int tilldonepath;
      public int etilldonepath;
      public int fromdonepath;
      public string filenametoload;
      //public UCCNC.SpindlePID SpindlePIDForm;
      //public UCCNC.Startupscreen splash;

      //public void Deletelaserimage(int imagenum) { }
      //public int Loadimage(Drawing.Image img) { return 0; }
      //public void Getborderandmarksize() { }
      //public void makedims() { }
      //public void Drawdimsimages() { }
      //public int Drawdimsimage(string text, float Length, float Arany, float diffX, float diffY, bool rotate, Drawing.Color col) { return 0; }
      //public void Seletscreenset() { }
      //public void Cameracapturetoggle() { }
      //public void Cameracaptureon() { }
      //public void Cameracaptureoff() { }
      //public void Reloadcameracapturedevicelist() { }
      //public void Movecameraoffset() { }
      //public void Cameragrayscalefiltertoggle() { }
      //public void Cameragrayscalefilteron() { }
      //public void Cameragrayscalefilteroff() { }
      //public void Cameraedgefiltertoggle() { }
      //public void Cameraedgefilteron() { }
      //public void Cameraedgefilteroff() { }
      //public void Increasecameratargetcircles() { }
      //public void Decreasecameratargetcircles() { }
      //public void Cameratargetlinetoggle() { }
      //public void Cameratargetlineon() { }
      //public void Cameratargetlineoff() { }
      //public void MovetocameraZheight() { }
      //public void Camerainvertimagetoggle() { }
      //public void Camerainvertimageon() { }
      //public void Camerainvertimageoff() { }
      //public void Setview45() { }
      //public void Setviewleft() { }
      //public void Setviewright() { }
      //public void Setviewtop() { }
      //public void Changeview() { }
      //public void DoXMLimport() { }
      //public void M3press() { }
      //public void M3doon() { }
      //public void M3dooff() { }
      //public void M4press() { }
      //public void M4doon() { }
      //public void M4dooff() { }
      //public void M7press() { }
      //public void M7doon() { }
      //public void M7dooff() { }
      //public void M8press() { }
      //public void M8doon() { }
      //public void M8dooff() { }
      //public void Setloadbarnewpos() { }
      //public void fitglcontrolsize() { }
      //public void hidejogger() { }
      //public void showjogger() { }
      //public void Hotkeyscheck() { }
      //public double Rollovercoords(double Val) { return 0; }
      //public void CAMCreatecode() { }
      //public void CAMGeneratepath() { }
      //public void CAMLoadDXF() { }
      //public void Comboboxselectionchanged(int boxnumber) { }
      //public void Mainformpreparation() { }
      //public void Closethisform(string errorstring) { }
      //public void Jogbuildpreparation() { }
      //public void Configuremacroloops() { }
      //public void Configureplugins() { }
      //public void Pluginshowupcaller(int pluginnumber) { }
      //public void Editscreen() { }
      //public void JogOff(int axis) { }
      //public void Toolpathhighlightcalc() { }
      //public string formatnumber1(Decimal Value) { return ""; }
      //public void ActivateForm() { }
      //public void TCPfollowon() { }
      //public void TCPfollowoff() { }
      //public void ToggleTCPfollow() { }
      //public void ShowZplatesetupWindow() { }
      //public void Initttooltip() { }
      //public string Getlicensename() { return ""; }
      //public bool IsProcessOpen(string name) { return false; }
      //public UCCNC.Compressionmethod GetOpenGLtexturecompressionmethod() { return new UCCNC.Compressionmethod(); }
      //public void setscreenrefreshrate(int vertexcount) { }
      //public void Setupsettings() { }
      //public void DoM5() { }
      //public void DoM9() { }
      //public void stopcodeexecution() { }
      //public void Fileload() { }
      //public void loadfile() { }
      //public void Filerewind() { }
      //public void Fileclose() { }
      //public void Setnextlinebuttonclicked(string linenumber) { }
      //public void Cyclestop() { }
      //public void Interpretmacrocode(string sender) { }
      //public void Interpretmacrolist(List<string> sender) { }
      //public void SendMDI(string MDItext, bool doMDIblink) { }
      //public void SendMDIthread() { }
      //public void setoffset(int G5x) { }
      //public void offlinepressed() { }
      //public void offlineon() { }
      //public void offlineoff() { }
      //public void Fileedit() { }
      //public void screenredrawcycle() { }
      //public void screenredrawcycle_clear() { }
      //public void screenredrawcycle_real() { }
      //public void Getclickedpoint(OpenTK.Vector2 our2DPoint) { }
      //public OpenTK.Vector3 from2Dto3D(OpenTK.Vector2 our2DPoint) { return new OpenTK.Vector3(); }
      //public OpenTK.Vector2 from3Dto2D(OpenTK.Vector3 our3DPoint) { return new OpenTK.Vector2(); }
      //public void makearrows() { }
      //public void makeZzeroplate() { }
      //public void makefloor() { }
      //public void resetscreen() { }
      //public void Zoomcontents() { }
      //public void Zoomminus() { }
      //public void Zoomplus() { }
      //public void SetviewISO() { }
   }
}