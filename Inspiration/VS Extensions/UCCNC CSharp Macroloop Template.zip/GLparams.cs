﻿#pragma warning disable CS0649

namespace UCCNC
{
   public struct GLparams
   {
      public int x;
      public int y;
      public int width;
      public int height;
      public bool visible;
   }
}