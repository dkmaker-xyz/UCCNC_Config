﻿#pragma warning disable CS0649

namespace UCCNC
{
   public struct Gstructloadoffset
   {
      public double? X;
      public double? Y;
      public double? Z;
      public double? A;
      public double? B;
      public double? C;
      public bool[] Isvar;
      public int L;
      public int offsetnumber;
      public double? R;
   }
}