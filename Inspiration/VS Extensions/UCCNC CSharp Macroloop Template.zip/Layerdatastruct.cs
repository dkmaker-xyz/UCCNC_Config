﻿#pragma warning disable CS0649

namespace Plugininterface.Datatypes
{
   public struct Layerdatastruct
   {
      public int Layernumber;
      public int Parentnumber;
      public bool Isactive;
   }
}