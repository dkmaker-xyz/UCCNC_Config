﻿#pragma warning disable CS0649

namespace UC100
{
   public struct Stat
   {
      public bool Idle;
      public bool Jog;
      public bool Dwell;
      public bool Backlash;
      public bool Home;
      public bool Probe;
      public bool Estop;
      public bool SoftLimit;
      public bool HardLimit;
      public int Puffer;
      public double Feed;
      public double SpindleRPM;
      public int CurrentID;
      public bool LimitOverride;
      public double OriginalFeed;
      public bool MPG1JogOn;
      public bool MPG2JogOn;
      public bool THCOnWaiting;
      public bool SyncThread;
      public bool SpindleOn;
      public bool SpindleDir;
      public bool LaserRunning;
      public bool LaserDataValid;
      public bool THCEnabled;
      public bool THCAntiDive;
      public bool THCAntiDiveEnable;
      public bool THCDelayEnable;
      public bool THCAntiDownEnable;
      public bool ProbeActive;
   }
}