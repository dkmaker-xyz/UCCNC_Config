﻿#pragma warning disable CS0649

namespace UCCNC
{
   public class Systemmessages
   {
      public Systemmessages() { }

      public string[] Message;
   }
}