﻿Imports System
Imports System.Collections.Generic
Imports System.Diagnostics
Imports System.Drawing
Imports System.Windows.Forms
Imports System.ComponentModel

Namespace UCCNC
    Public Class Executer
        Public Shared substackdepth As Integer
        Public Shared ivarssize As Integer
        Public Shared LEDssize As Integer

        'public Executer(UCCNC.Form1 mainform) { }
        Public Sub New()
        End Sub

        Public Rulerproperties As UCCNC.Rulerstruct
        Public LaserimageStartX As Double
        Public LaserimageStartY As Double
        Public Overrundistance As Double
        Public laserimageDiffX As Single
        Public laserimageDiffY As Single
        Public LaserimageWidth As Double
        Public LaserimageHeight As Double
        Public Laserimagenumber As Integer
        Public actfeedratemode As Integer
        Public Modalcodes As Double()
        Public acttooloffsetnumber As Integer
        Public acttooloffsetmodal As Integer
        Public GUIdisabled As Boolean
        Public Ismacrorun As Integer()
        Public CycleStopped As Boolean
        Public Filereloadcommand As Boolean
        'public UCCNC.Tooltabledetailed Tooltable;
        'public UCCNC.Rcomperrorform RcomperrForm;
        Public ArcstartposX As Double
        Public ArcstartposY As Double
        'public UCCNC.Rcompensator DC;
        Public G68active As Boolean
        Public rotX As Double
        Public rotY As Double
        Public rotAngle As Double
        Public scaleX As Double
        Public scaleY As Double
        Public scaleZ As Double
        Public scaleA As Double
        Public scaleB As Double
        Public scaleC As Double
        Public tabbing As Boolean
        'public List<UCCNC.Executer.Axesposition> Probepoints;
        Public Fieldenteredscreennumber As Integer
        Public Totaltime As TimeSpan
        Public M3time As TimeSpan
        Public M4time As TimeSpan
        Public Cyclestime As TimeSpan
        Public Totaltimestopwatch As Stopwatch
        Public M3timestopwatch As Stopwatch
        Public M4timestopwatch As Stopwatch
        Public Cyclestimestopwatch As Stopwatch
        Public TotalM3s As Integer
        Public TotalM4s As Integer
        Public TotalM7s As Integer
        Public TotalM8s As Integer
        Public hotkeysenabled As Boolean
        Public OperatorPassword As String
        Public Lastactionwasstepjog As Boolean
        Public Xstepjogpos As Double
        Public Call1000 As Boolean
        Public THCvirtualARCON As Boolean
        Public THCvirtualUP As Boolean
        Public THCvirtualDOWN As Boolean
        'public UCCNC.Questionbox Questionbox1;
        Public didinitialmovement As Boolean
        Public IsHoming As Boolean
        Public rememberjogmode As Integer
        Public looprun As Boolean()
        Public laststatusmessage As String
        Public fileloading As Boolean
        Public destructed As Boolean
        Public feedholdbuttonstate As Boolean
        Public Isfeedhold As Boolean
        Public stepjoggoing As Boolean
        Public MDInumber As Integer
        Public calledfromscreen As Boolean
        Public homi As Integer
        Public dohoming As Boolean
        Public constructmacro As Boolean
        Public destructmacro As Boolean
        'public UCCNC.IniReader profile;
        Public ISenableLEDset As Boolean()
        Public AnIn1 As Integer
        Public AnIn2 As Integer
        Public AnIn3 As Integer
        Public AnIn4 As Integer
        Public AnOut1 As Integer
        Public AnOut2 As Integer
        Public AnOut3 As Integer
        Public AnOut4 As Integer
        Public MPGaxis As Integer
        Public MPGmode As Integer
        Public ivars As Double()
        Public actualdistmode As Integer
        Public Isabs As Boolean
        Public Substack As List(Of UCCNC.Substackstruct)
        Public SubstackR As List(Of Integer)
        Public MDIstopped As Boolean
        Public actualmodal As Integer
        Public prevmodal As Integer
        Public MachposQ As Double?
        Public MachposK As Double?
        Public PeckZ As Double?
        'public UCCNC.Runfromhereform RFH;
        Public doinitialmovement As Boolean
        Public setnextlinepressed As Boolean
        Public eWzval As Double
        Public eTOZval As Double
        Public jogXpbuttonpressed As Boolean
        Public jogXmbuttonpressed As Boolean
        Public jogYpbuttonpressed As Boolean
        Public jogYmbuttonpressed As Boolean
        Public jogZpbuttonpressed As Boolean
        Public jogZmbuttonpressed As Boolean
        Public jogApbuttonpressed As Boolean
        Public jogAmbuttonpressed As Boolean
        Public jogBpbuttonpressed As Boolean
        Public jogBmbuttonpressed As Boolean
        Public jogCpbuttonpressed As Boolean
        Public jogCmbuttonpressed As Boolean
        Public grabbedkey As Integer
        Public macrocall As Boolean
        Public macroloopcall As Boolean
        Public showmachinecoords As Boolean
        Public Loadimages As Boolean
        Public Loadmainscreen As Boolean
        Public Loadjogscreen As Boolean
        Public LEDstates As Integer()
        Public Buttonstates As Boolean()
        Public Limitsoverridemode As Boolean
        Public Offlinemode As Boolean
        Public jogmode As Integer
        Public jogsteprate As Double
        Public Xhomed As Boolean
        Public Yhomed As Boolean
        Public Zhomed As Boolean
        Public Ahomed As Boolean
        Public Bhomed As Boolean
        Public Chomed As Boolean
        Public JogFeedrate As Double
        Public Currenttool As Integer
        Public macrostop As Boolean
        Public newstatusmessage As String
        Public digitsformat As String
        Public actualprofilename As String
        Public Wx As Double
        Public Wy As Double
        Public Wz As Double
        Public Wa As Double
        Public Wb As Double
        Public Wc As Double
        Public Oz As Double
        Public ofc As UCCNC.Offsetcontrol
        Public UCstat As UC100.Stat
        Public Sstat As UC100.Stat
        Public GetlineUCstat As UC100.Stat
        Public SetvarUCstat As UC100.Stat
        Public actualfeedoverride As Double
        Public Xstepsize As Double
        Public Ystepsize As Double
        Public Zstepsize As Double
        Public Astepsize As Double
        Public Bstepsize As Double
        Public Cstepsize As Double
        Public actualSS As Double
        Public currentOutput As Long
        Public dwelltime As Double
        Public [exit] As Boolean
        Public joghidden As Boolean
        Public M3on As Boolean
        Public M4on As Boolean
        Public M7on As Boolean
        Public M8on As Boolean
        Public MDIgo As Boolean
        Public lastfeed As Double
        Public Estopin As Boolean
        Public go As Boolean
        Public stopped As Boolean
        Public mainform As UCCNC.Form1
        Public startobjectnumber As Integer
        Public cyclerunner As BackgroundWorker
        Public MDIrunner As BackgroundWorker
        Public gcodelinenumber As Integer
        Public theAutozero As Boolean
        Public actplane As Integer
        Public actcannedreturnlevel As Integer

        Public Function TextQuestion(ByVal Questiontext As String) As String
            Return ""
        End Function
        Public Function Question(ByVal Questiontext As String) As Double
            Return 0
        End Function
        Public Sub Virtual_THCarcon(ByVal Ison As Boolean)
        End Sub
        Public Sub Virtual_THCup(ByVal Ison As Boolean)
        End Sub
        Public Sub Virtual_THCdown(ByVal Ison As Boolean)
        End Sub
        Public Sub OperatorLock()
        End Sub
        Public Sub Showstatistics()
        End Sub
        Public Sub Jograpiddisable(ByVal disable As Boolean)
        End Sub
        Public Sub Jogdisable(ByVal disable As Boolean)
        End Sub
        Public Function Showplugin(ByVal pluginfilename As String) As Integer
            Return 0
        End Function
        Public Function Configplugin(ByVal pluginfilename As String) As Integer
            Return 0
        End Function
        Public Function GetAllModbusArray() As UShort()
            Return New UShort(-1) {}
        End Function
        Public Function SetModbusregister(ByVal Registernumber As Integer, ByVal Value As UShort) As Boolean
            Return False
        End Function
        Public Function SetModbusregisters(ByVal Startregister As Integer, ByVal Values As UShort()) As Boolean
            Return False
        End Function
        Public Function GetModbusregister(ByVal Registernumber As Integer, ByVal Value As UShort) As Boolean
            Return False
        End Function
        Public Function GetModbusregisters(ByVal Startregister As Integer, ByVal Registercount As Integer, ByVal Values As UShort()) As Boolean
            Return False
        End Function
        Public Sub WriteModbusString(ByVal Str As String, ByVal Startregister As Integer, ByVal HightoLowByteorder As Boolean)
        End Sub
        Public Function IsOdd(ByVal value As Integer) As Boolean
            Return False
        End Function
        Public Sub Showspindlepulleys()
        End Sub
        Public Sub Startdigitizing()
        End Sub
        Public Sub Stopdigitizing()
        End Sub
        Public Sub StopdigitizingDelegated()
        End Sub
        Public Sub Setdigitizefilename()
        End Sub
        Public Function Getvar(ByVal varnum As Integer) As Double
            Return 0
        End Function
        Public Sub Setvar(ByVal value As Double, ByVal varnum As Integer)
        End Sub
        Public Sub Toggletabbing()
        End Sub
        Public Sub Tabbingoff()
        End Sub
        Public Sub Tabbingon()
        End Sub
        Public Sub JogfeedResetto100percent()
        End Sub
        Public Sub FROResetto100percent()
        End Sub
        Public Sub SROResetto100percent()
        End Sub
        Public Sub M1optionalstopon()
        End Sub
        Public Sub M1optionalstopoff()
        End Sub
        Public Sub ToggleM1optionalstop()
        End Sub
        Public Sub Deleteallprecompiledmacros()
        End Sub
        Public Sub Precompileallmacros()
        End Sub
        Public Sub Createinternalmacroslist()
        End Sub
        Public Function Informplugin(ByVal Pluginfilename As String, ByVal Message As Object) As Object
            Return New [Object]()
        End Function
        Public Sub Informplugins(ByVal Message As Object)
        End Sub
        Public Sub Setupsliders()
        End Sub
        Public Sub OpenSpindlePIDsetupwindow()
        End Sub
        Public Sub RemoveRunfromhere()
        End Sub
        Public Sub CoordsTransform(ByVal Xval As Double, ByVal Yval As Double, ByVal Zval As Double, ByVal Aval As Double, ByVal Bval As Double, ByVal Cval As Double)
        End Sub
        Public Sub CoordsTransformABS(ByVal Xval As Double, ByVal Yval As Double, ByVal Zval As Double, ByVal Aval As Double, ByVal Bval As Double, ByVal Cval As Double, ByVal Xmove As Boolean, ByVal Ymove As Boolean, ByVal Zmove As Boolean, ByVal Amove As Boolean, ByVal Bmove As Boolean, ByVal Cmove As Boolean)
        End Sub
        Public Sub CoordsTransformInv(ByVal Xval As Double?, ByVal Yval As Double?, ByVal Zval As Double?, ByVal Aval As Double?, ByVal Bval As Double?, ByVal Cval As Double?)
        End Sub
        Public Sub ScalevectorInv(ByVal Xval As Double?, ByVal Yval As Double?, ByVal Zval As Double?, ByVal Aval As Double?, ByVal Bval As Double?, ByVal Cval As Double?)
        End Sub
        Public Sub Rotatevector(ByVal Xval As Double, ByVal Yval As Double)
        End Sub
        Public Sub RotatevectorInv(ByVal Xval As Double?, ByVal Yval As Double?)
        End Sub
        Public Sub ShowTooltable()
        End Sub
        Public Sub ShowRcomperrorlist()
        End Sub
        Public Function Getgcodelinetext(ByVal rownumber As Integer) As String
            Return ""
        End Function
        Public Function Getcurrgcodelinetext() As String
            Return ""
        End Function
        Public Function Getcurrentgcodelinenumber() As Integer
            Return 0
        End Function
        Public Function Ismacrorunning(ByVal macronumber As Integer) As Integer
            Return 0
        End Function
        Public Function IsGUIdisabled() As Boolean
            Return False
        End Function
        Public Sub DisableGUI(ByVal disable As Boolean)
        End Sub
        Public Function Isfillshown() As Boolean
            Return False
        End Function
        Public Function Getlayerslist(ByVal isAS3 As Boolean) As List(Of Plugininterface.Datatypes.Layerdatastruct)
            Return New List(Of Plugininterface.Datatypes.Layerdatastruct)()
        End Function
        Public Sub Getmainwindowproperties(ByVal Windowlocation As Point, ByVal Windowsize As Size)
        End Sub
        Public Function Gettooltabledata() As Plugininterface.Datatypes.Tooltablestruct()
            Return New Plugininterface.Datatypes.Tooltablestruct(-1) {}
        End Function
        Public Function Getactualmodalcode(ByVal groupnumber As Integer) As Double
            Return 0
        End Function
        Public Function Isresetactive(ByVal Showresetmessage As Boolean) As Boolean
            Return False
        End Function
        Public Sub Disableproberadius(ByVal Disable As Boolean)
        End Sub
        Public Sub OKwindow()
        End Sub
        Public Sub Newtoolselection(ByVal val As Double)
        End Sub
        Public Sub Changeselectedtool()
        End Sub
        Public Sub ChangeSetFeedRateDRO_event(ByVal val As Double)
        End Sub
        Public Sub ChangeSetSpindleSpeedDRO_event(ByVal val As Double)
        End Sub
        Public Sub Getcutdistancestatistics(ByVal X As Double, ByVal Y As Double, ByVal Z As Double, ByVal A As Double, ByVal B As Double, ByVal C As Double, ByVal CutX As Double, ByVal CutY As Double, ByVal CutZ As Double, ByVal CutA As Double, ByVal CutB As Double, ByVal CutC As Double)
        End Sub
        Public Sub Setlaserimage(ByVal img As Image, ByVal StartX As Double, ByVal StartY As Double, ByVal Width As Double, ByVal Height As Double, ByVal Overrundistance As Double)
        End Sub
        Public Sub Toggletoolpathdimensionsvisibility()
        End Sub
        Public Sub Toolpathdimensionsvisibilityon()
        End Sub
        Public Sub Toolpathdimensionsvisibilityoff()
        End Sub
        Public Function IsValidPortPin(ByVal port As Integer, ByVal pin As Integer, ByVal isoutput As Boolean) As Boolean
            Return False
        End Function
        Public Sub physicalzeroaxis(ByVal axisnumber As Integer, ByVal value As Double)
        End Sub
        Public Sub ClearM0M1M60LEDs()
        End Sub
        Public Sub rewindfile()
        End Sub
        Public Sub writejobproperties()
        End Sub
        Public Function fnum(ByVal Value As Double) As String
            Return ""
        End Function
        Public Function fnum4digits(ByVal Value As Double) As String
            Return ""
        End Function
        Public Sub Setoutpin(ByVal portnumber As Integer, ByVal pinnumber As Integer)
        End Sub
        Public Sub Clroutpin(ByVal portnumber As Integer, ByVal pinnumber As Integer)
        End Sub
        Public Function GetUCpin(ByVal Port As Integer, ByVal Pin As Integer, ByVal Isoutput As Boolean) As Integer
            Return 0
        End Function
        Public Function getUCpinfromportsandpinslabels(ByVal portlabel As Integer, ByVal pinlabel As Integer, ByVal Isoutput As Boolean) As Integer
            Return 0
        End Function
        Public Function SetOutBit(ByVal bitnumber As Integer) As Integer
            Return 0
        End Function
        Public Function ClrOutBit(ByVal bitnumber As Integer) As Integer
            Return 0
        End Function
        Public Sub editGcodefile()
        End Sub
        Public Function Checkifinposition(ByVal Xtomove As Double, ByVal Ytomove As Double, ByVal Ztomove As Double) As Boolean
            Return False
        End Function
        Public Function Checkiffullcircle(ByVal Xtomove As Double, ByVal Ytomove As Double, ByVal Ztomove As Double) As Boolean
            Return False
        End Function
        Public Sub AddLinear(ByVal XX As Double, ByVal YY As Double, ByVal ZZ As Double, ByVal AA As Double, ByVal BB As Double, ByVal CC As Double, ByVal Feed As Double, ByVal ID As Integer)
        End Sub
        Public Sub AddLinearABS(ByVal XX As Double, ByVal YY As Double, ByVal ZZ As Double, ByVal AA As Double, ByVal BB As Double, ByVal CC As Double, ByVal Xmove As Boolean, ByVal Ymove As Boolean, ByVal Zmove As Boolean, ByVal Amove As Boolean, ByVal Bmove As Boolean, ByVal Cmove As Boolean, ByVal Feed As Double, ByVal ID As Integer)
        End Sub
        Public Sub AddCircular(ByVal XX As Double, ByVal YY As Double, ByVal ZZ As Double, ByVal rXX As Double, ByVal rYY As Double, ByVal dir As Boolean, ByVal Feed As Double, ByVal Plane As Integer, ByVal ID As Integer, ByVal NextID As Integer)
        End Sub
        Public Sub AddSyncMoveP(ByVal XX As Double?, ByVal ZZ As Double?, ByVal PP As Double, ByVal QQ As Double?, ByVal ID As Integer)
        End Sub
        Public Sub AddRigidTappingMove(ByVal ZZ As Double, ByVal KK As Double, ByVal DIR As Boolean, ByVal ID As Integer)
        End Sub
        Public Sub AddDummy(ByVal ID As Integer)
        End Sub
        Public Sub decrypt(ByVal serialfilename As String, ByVal name As String, ByVal serial As String)
        End Sub
        Public Sub Setaxishomestate(ByVal axis As Integer, ByVal Ishomed As Boolean)
        End Sub
        Public Sub Derefallaxeshomes()
        End Sub
        Public Sub SetJRO()
        End Sub
        Public Sub SetupEncodersettings()
        End Sub
        Public Sub SwitchMPG()
        End Sub
        Public Sub MPGaxisselect(ByVal axisnumber As Integer)
        End Sub
        Public Sub MPGmodeselect(ByVal mode As Integer)
        End Sub
        Public Sub Takecareofcheckboxes(ByVal Checkboxnumber As Integer, ByVal IsOn As Boolean)
        End Sub
        Public Sub ClearG92offset()
        End Sub
        Public Sub Inputlabelvaluechangedint(ByVal box As Integer, ByVal val As Integer, ByVal Slider As Boolean)
        End Sub
        Public Sub Inputlabelvaluechanged(ByVal box As String, ByVal val As String, ByVal Slider As Boolean)
        End Sub
        Public Sub Setnewselectedrownumberint(ByVal val As Integer)
        End Sub
        Public Sub Setnewselectedrownumber(ByVal val As String)
        End Sub
        Public Sub ChangeSSODROvalue(ByVal val As String)
        End Sub
        Public Sub ChangeFRODROvalue(ByVal val As String)
        End Sub
        Public Sub ChangeaxisDROvalue(ByVal axisnumber As Integer, ByVal val As String)
        End Sub
        Public Sub offsetcurrentpos(ByVal offsetnumber As Integer)
        End Sub
        Public Sub clearworkoffset(ByVal offsetnumber As Integer)
        End Sub
        Public Sub cleartooloffset()
        End Sub
        Public Sub Setversiontext()
        End Sub
        Public Sub Setscreennumformat(ByVal Digitplaces As Integer)
        End Sub
        Public Sub Zeroworktimer()
        End Sub
        Public Function Getcodetotalruntimemsec() As Long
            Return 0
        End Function
        Public Sub Calibrateaxis(ByVal Axisnumber As Integer)
        End Sub
        Public Sub Sethotkey(ByVal keylabelnumber As Integer)
        End Sub
        Public Sub Setfunctionkey(ByVal keylabelnumber As Integer)
        End Sub
        Public Sub SetLEDkey(ByVal keylabelnumber As Integer)
        End Sub
        Public Sub Loadfile(ByVal filename As String)
        End Sub
        Public Sub Reloadfile()
        End Sub
        Public Function IsLoading() As Boolean
            Return False
        End Function
        Public Function IsSoftlimit() As Boolean
            Return False
        End Function
        Public Function IsMoving() As Boolean
            Return False
        End Function
        Public Function IsMovingTHC() As Boolean
            Return False
        End Function
        Public Function IsMovingFast() As Boolean
            Return False
        End Function
        Public Function IsMovingforHomeing() As Boolean
            Return False
        End Function
        Public Sub Setcurrenttool(ByVal toolnumber As Integer)
        End Sub
        Public Function Getcurrenttool() As Integer
            Return 0
        End Function
        Public Function Getnewtool() As Integer
            Return 0
        End Function
        Public Function GetXmachpos() As Double
            Return 0
        End Function
        Public Function GetYmachpos() As Double
            Return 0
        End Function
        Public Function GetZmachpos() As Double
            Return 0
        End Function
        Public Function GetAmachpos() As Double
            Return 0
        End Function
        Public Function GetBmachpos() As Double
            Return 0
        End Function
        Public Function GetCmachpos() As Double
            Return 0
        End Function
        Public Function GetXpos() As Double
            Return 0
        End Function
        Public Function GetYpos() As Double
            Return 0
        End Function
        Public Function GetZpos() As Double
            Return 0
        End Function
        Public Function GetApos() As Double
            Return 0
        End Function
        Public Function GetBpos() As Double
            Return 0
        End Function
        Public Function GetCpos() As Double
            Return 0
        End Function
        Public Sub StopWithDeccel()
        End Sub
        Public Sub [Stop]()
        End Sub
        Public Sub Wait(ByVal szam As Integer)
        End Sub
        Public Sub CodesyncCallfromplugin(ByVal Macrocode As String)
        End Sub
        Public Sub Codesync(ByVal thecode As String)
        End Sub
        Public Sub Code(ByVal Macrocode As String)
        End Sub
        Public Sub CodelistCallfromplugin(ByVal Macrocodelist As List(Of String))
        End Sub
        Public Sub Codelist(ByVal Macrocodelist As List(Of String))
        End Sub
        Public Sub Setofflinemode(ByVal setoffline As Boolean)
        End Sub
        Public Function Ismacrostopped() As Boolean
            Return False
        End Function
        Public Function GetLED(ByVal LEDnumber As Integer) As Boolean
            Return False
        End Function
        Public Sub SetLED(ByVal val As Boolean, ByVal LEDnumber As Integer)
        End Sub
        Public Sub Pluginshowup(ByVal Pluginfilename As String)
        End Sub
        Public Function Getanaloginput(ByVal channel As Integer) As Integer
            Return 0
        End Function
        Public Function Getanalogoutput(ByVal channel As Integer) As Integer
            Return 0
        End Function
        Public Sub Swapaxis(ByVal axis1 As Integer, ByVal axis2 As Integer)
        End Sub
        Public Sub Resetswapaxis()
        End Sub
        Public Sub Slaveaxis(ByVal masteraxis As Integer, ByVal pSlaveaxis As Integer)
        End Sub
        Public Function Getbuttonsdescriptions() As List(Of UCCNC.Functionproperties)
            Return New List(Of UCCNC.Functionproperties)()
        End Function
        Public Function GetLEDsdescriptions() As List(Of UCCNC.Functionproperties)
            Return New List(Of UCCNC.Functionproperties)()
        End Function
        Public Sub Callbutton_fromscreen(ByVal bn As Integer)
        End Sub
        Public Sub Callbutton_fromscreen_thr(ByVal buttonnumber As Integer)
        End Sub
        Public Sub Callbutton(ByVal bn As Integer)
        End Sub
        Public Sub Callbutton_directly(ByVal buttonnumber As Integer)
        End Sub
        Public Sub Writekey(ByVal section As String, ByVal key As String, ByVal value As String)
        End Sub
        Public Function Readkey(ByVal section As String, ByVal key As String, ByVal defaultvalue As String) As String
            Return ""
        End Function
        Public Sub Setbuttonstate(ByVal buttonnumber As Integer, ByVal Ison As Boolean)
        End Sub
        Public Sub RestartApp(ByVal args As String)
        End Sub
        Public Sub Stopjogging()
        End Sub
        Public Sub AddDwell(ByVal time As Double, ByVal ID As Integer)
        End Sub
        Public Function GetAllmacrovars(ByVal vars As UCCNC.Allvarstruct) As UCCNC.Allvarstruct
            Return New UCCNC.Allvarstruct()
        End Function
        Public Function Getgcodefilename() As String
            Return ""
        End Function
        Public Sub SetRotate(ByVal Rx As Double, ByVal Ry As Double, ByVal Rangle As Double)
        End Sub
        Public Sub GetRotate(ByVal Rx As Double, ByVal Ry As Double, ByVal Angle As Double)
        End Sub
        Public Sub SetScale(ByVal ScX As Double?, ByVal ScY As Double?, ByVal ScZ As Double?, ByVal ScA As Double?, ByVal ScB As Double?, ByVal ScC As Double?)
        End Sub
        Public Sub SetScaleX(ByVal ScX As Double)
        End Sub
        Public Sub SetScaleY(ByVal ScY As Double)
        End Sub
        Public Sub SetScaleZ(ByVal ScZ As Double)
        End Sub
        Public Sub SetScaleA(ByVal ScA As Double)
        End Sub
        Public Sub SetScaleB(ByVal ScB As Double)
        End Sub
        Public Sub SetScaleC(ByVal ScC As Double)
        End Sub
        Public Function GetXscale() As Double
            Return 0
        End Function
        Public Function GetYscale() As Double
            Return 0
        End Function
        Public Function GetZscale() As Double
            Return 0
        End Function
        Public Function GetAscale() As Double
            Return 0
        End Function
        Public Function GetBscale() As Double
            Return 0
        End Function
        Public Function GetCscale() As Double
            Return 0
        End Function
        Public Function GetPlane() As Integer
            Return 0
        End Function
        Public Sub SetPlane(ByVal plane As Integer, ByVal ID As Integer)
        End Sub
        Public Sub SetPathmode(ByVal mode As Integer, ByVal ID As Integer)
        End Sub
        Public Function GetPathmode() As Integer
            Return 0
        End Function
        Public Sub SetCannedreturnlevel(ByVal level As Integer, ByVal ID As Integer)
        End Sub
        Public Function GetCannedreturnlevel() As Integer
            Return 0
        End Function
        Public Sub Doaxiscalibration(ByVal axisnumber As Integer)
        End Sub
        Public Sub Activateoffset(ByVal offsetnumber As Integer)
        End Sub
        Public Sub Loadoffset(ByVal Gt As UCCNC.Gstructloadoffset)
        End Sub
        Public Sub LimitsOverride()
        End Sub
        Public Sub ClearStatusmessage()
        End Sub
        Public Sub AddStatusmessage(ByVal newmessage As String)
        End Sub
        Public Sub goOffline()
        End Sub
        Public Sub goOnline()
        End Sub
        Public Sub doprobe()
        End Sub
        Public Sub zeroaxis(ByVal axisnumber As Integer, ByVal value As Double)
        End Sub
        Public Sub Showreseterror()
        End Sub
        Public Sub Showstuckedjogkeyerror()
        End Sub
        Public Sub Showoutoflimitserror()
        End Sub
        Public Sub Showerrormessage(ByVal windowmessage As String, ByVal statusmessage As String, ByVal Isdialog As Boolean)
        End Sub
        Public Sub Showerrormessagesync(ByVal windowmessage As String, ByVal statusmessage As String, ByVal Isdialog As Boolean)
        End Sub
        Public Sub Setpulley()
        End Sub
        Public Sub Setspindlespeed(ByVal setspeed As Double)
        End Sub
        Public Sub Gotozero()
        End Sub
        'public bool executeMDIline(UCCNC.Gobject ggc) { return false; }
        'public bool executeMacroline(UCCNC.Gobject ggc) { return false; }
        Public Sub Getactualoffset()
        End Sub
        Public Sub Initfeed()
        End Sub
        Public Function getstoppedlinenumber() As Integer
            Return 0
        End Function
        Public Function getcurrentfeedrate() As Double
            Return 0
        End Function
        Public Function getstoppedobjectnumber(ByVal linenumber As Integer) As Integer
            Return 0
        End Function
        Public Function getfirstobjectnumberinrow(ByVal linenumber As Integer) As Integer
            Return 0
        End Function
        Public Function getlastobjectnumberinrow(ByVal linenumber As Integer) As Integer
            Return 0
        End Function
        Public Function getbuffer() As Integer
            Return 0
        End Function
        Public Sub DospinCW()
        End Sub
        Public Sub DospinCWND()
        End Sub
        Public Sub DospinCCW()
        End Sub
        Public Sub DospinCCWND()
        End Sub
        Public Sub Stopspin()
        End Sub
        Public Sub StopspinND()
        End Sub
        Public Sub Miston()
        End Sub
        Public Sub MistonND()
        End Sub
        Public Sub Floodon()
        End Sub
        Public Sub FloodonND()
        End Sub
        Public Sub Stopcoolant()
        End Sub
        Public Sub StopcoolantND()
        End Sub
        Public Sub StopmistND()
        End Sub
        Public Sub StopfloodND()
        End Sub
        Public Function fitnumseparator(ByVal szam As String) As Double
            Return 0
        End Function
        Public Function fitnumseparatorstr(ByVal num As String) As String
            Return ""
        End Function
        Public Sub Togglesoftlimits()
        End Sub
        Public Sub softlimitson()
        End Sub
        Public Sub softlimitsoff()
        End Sub
        Public Sub Setsoftlimits(ByVal enable As Boolean)
        End Sub
        Public Sub ToggleTHC()
        End Sub
        Public Sub THCon()
        End Sub
        Public Sub THCoff()
        End Sub
        Public Sub SetTHC(ByVal enable As Boolean)
        End Sub
        Public Sub ToggleTHCantidive()
        End Sub
        Public Sub THCantidiveon()
        End Sub
        Public Sub THCantidiveoff()
        End Sub
        Public Sub SetTHCantidive(ByVal enable As Boolean)
        End Sub
        Public Sub ToggleTHCantidown()
        End Sub
        Public Sub THCantidownon()
        End Sub
        Public Sub THCantidownoff()
        End Sub
        Public Sub SetTHCantidown(ByVal enable As Boolean)
        End Sub
        Public Sub ToggleTHCdelay()
        End Sub
        Public Sub THCdelayon()
        End Sub
        Public Sub THCdelayoff()
        End Sub
        Public Sub SetTHCdelay(ByVal enable As Boolean)
        End Sub
        Public Sub Safeprobeon()
        End Sub
        Public Sub Safeprobeoff()
        End Sub
        Public Sub Togglesafeprobe()
        End Sub
        Public Sub Jogsafeprobeon()
        End Sub
        Public Sub Jogsafeprobeoff()
        End Sub
        Public Sub Togglejogsafeprobe()
        End Sub
        Public Sub GetCyclestartinitialcoordinates(ByVal line As Integer)
        End Sub
        Public Sub updatelaserprogress(ByVal state As Integer)
        End Sub
        Public Function CheckifHomed() As Boolean
            Return False
        End Function
        Public Sub Cyclestart()
        End Sub
        Public Sub Runsingleline()
        End Sub
        Public Sub Togglefeedhold()
        End Sub
        Public Sub Feedholdon()
        End Sub
        Public Sub Feedholdoff()
        End Sub
        Public Sub CycleStart(ByVal startobjectnumber As Integer, ByVal endobjectnumber As Integer, ByVal singlerun As Boolean)
        End Sub
        Public Sub CycleStopwithDeccel()
        End Sub
        Public Sub setjograte(ByVal val As Double)
        End Sub
        Public Sub increasejograte()
        End Sub
        Public Sub decreasejograte()
        End Sub
        Public Sub changejograte(ByVal jogselection As Integer)
        End Sub
        Public Sub changejogmode(ByVal jogmode As Integer)
        End Sub
        Public Sub stepjog(ByVal axis As Integer, ByVal directionnegative As Boolean, ByVal currjogmode As Integer)
        End Sub
        Public Sub DoHomeAll(ByVal isG28 As Boolean)
        End Sub
        Public Sub Dohomeallthread()
        End Sub
        Public Sub DoSingleHome(ByVal Axis As Integer, ByVal speedup As Double, ByVal speeddown As Double, ByVal dir As Boolean, ByVal Autozero As Boolean, ByVal isG28 As Boolean, ByVal isAllhomesequence As Boolean)
        End Sub
    End Class
End Namespace