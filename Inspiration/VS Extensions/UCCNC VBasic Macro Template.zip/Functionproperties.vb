﻿Namespace UCCNC
    Public Structure Functionproperties
        Public functioncode As Integer
        Public functionname As String
        Public functiondescription As String
    End Structure
End Namespace