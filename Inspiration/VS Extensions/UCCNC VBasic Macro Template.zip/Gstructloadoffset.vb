﻿Namespace UCCNC
    Public Structure Gstructloadoffset
        Public X As Double?
        Public Y As Double?
        Public Z As Double?
        Public A As Double?
        Public B As Double?
        Public C As Double?
        Public Isvar As Boolean()
        Public L As Integer
        Public offsetnumber As Integer
        Public R As Double?
    End Structure
End Namespace