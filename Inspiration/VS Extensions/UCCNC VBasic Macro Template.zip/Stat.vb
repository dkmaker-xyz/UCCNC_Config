﻿Namespace UC100
    Public Structure Stat
        Public Idle As Boolean
        Public Jog As Boolean
        Public Dwell As Boolean
        Public Backlash As Boolean
        Public Home As Boolean
        Public Probe As Boolean
        Public Estop As Boolean
        Public SoftLimit As Boolean
        Public HardLimit As Boolean
        Public Puffer As Integer
        Public Feed As Double
        Public SpindleRPM As Double
        Public CurrentID As Integer
        Public LimitOverride As Boolean
        Public OriginalFeed As Double
        Public MPG1JogOn As Boolean
        Public MPG2JogOn As Boolean
        Public THCOnWaiting As Boolean
        Public SyncThread As Boolean
        Public SpindleOn As Boolean
        Public SpindleDir As Boolean
        Public LaserRunning As Boolean
        Public LaserDataValid As Boolean
        Public THCEnabled As Boolean
        Public THCAntiDive As Boolean
        Public THCAntiDiveEnable As Boolean
        Public THCDelayEnable As Boolean
        Public THCAntiDownEnable As Boolean
        Public ProbeActive As Boolean
    End Structure
End Namespace