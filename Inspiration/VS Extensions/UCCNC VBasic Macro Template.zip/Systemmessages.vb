﻿Namespace UCCNC
    Public Class Systemmessages
        Public Sub New()
        End Sub

        Public Message As String()
    End Class
End Namespace