﻿Imports System.Collections.Generic

Namespace UCCNC
    Public Class AS3interfaceClass
        Public Shared Function HtmlEncode(ByVal text As String) As String
            Return ""
        End Function

        'public AS3interfaceClass(UCCNC.Form1 mainform, int screennumber, OpenTK.GLControl screenobj) { }
        Public Sub New()
        End Sub

        'public UCCNC.Form1 mainform;
        'public UCCNC.GUI mainGUI;
        Public UCstat As UC100.Stat
        Public screennumber As Integer
        Public screensizeX As Integer
        Public screensizeY As Integer
        'public OpenTK.GLControl screenobj;
        Public Layeriniselects As List(Of Integer)
        Public glpar As UCCNC.GLparams()
        Public CAMcanvassizeX As Integer
        Public CAMcanvassizeY As Integer
        Public gcodetext As String

        Public Sub Setjogpaneltabsize(ByVal tabsize As Integer)
        End Sub
        Public Sub Setscreensize(ByVal x As Integer, ByVal y As Integer)
        End Sub
        Public Sub SendallIOledstoscreen(ByVal Xpos As Double, ByVal Ypos As Double, ByVal Xgrid As Double, ByVal Ygrid As Double, ByVal sizeX As Integer, ByVal sizeY As Integer, ByVal outtypeLEDnum As Integer, ByVal intypeLEDnum As Integer, ByVal layernum As Integer)
        End Sub
        Public Sub Addallioleds(ByVal Xpos As Double, ByVal Ypos As Double, ByVal Xgrid As Double, ByVal Ygrid As Double, ByVal sizeX As Integer, ByVal sizeY As Integer, ByVal outtypeLEDnum As Integer, ByVal intypeLEDnum As Integer, ByVal layernum As Integer)
        End Sub
        Public Sub Loadpicture(ByVal pictureupURL As String, ByVal picturedownURL As String, ByVal picturenumber As Integer, ByVal IsLastpicturetoload As Boolean)
        End Sub
        Public Sub Sendlisttoscreen(ByVal labelfont As String, ByVal textalign As String, ByVal fontsize As Integer, ByVal fontcolor As Integer, ByVal posX As Integer, ByVal posY As Integer, ByVal Width As Integer, ByVal Height As Integer, ByVal labelnumber As Integer, ByVal layernumber As Integer)
        End Sub
        Public Sub Addlist(ByVal labelfont As String, ByVal textalign As String, ByVal fontsize As Integer, ByVal fontcolor As Integer, ByVal posX As Integer, ByVal posY As Integer, ByVal Width As Integer, ByVal Height As Integer, ByVal labelnumber As Integer, ByVal layernumber As Integer)
        End Sub
        Public Sub Addlist(ByVal labelfont As String, ByVal textalign As String, ByVal fontsize As Integer, ByVal fontcolor As Integer, ByVal backcolor As Integer, ByVal transparency As Double, ByVal posX As Integer, ByVal posY As Integer, ByVal Width As Integer, ByVal Height As Integer, ByVal labelnumber As Integer, ByVal layernumber As Integer)
        End Sub
        Public Sub Additemtolist(ByVal val As String, ByVal labelnumber As Integer)
        End Sub
        Public Sub Additemtolistbeginning(ByVal val As String, ByVal labelnumber As Integer)
        End Sub
        Public Function Getlist(ByVal labelnumber As Integer) As List(Of String)
            Return New List(Of String)()
        End Function
        Public Function GetMDIhistory() As List(Of String)
            Return New List(Of String)()
        End Function
        Public Sub ClearMDIhistory()
        End Sub
        Public Sub Addslider(ByVal x As Integer, ByVal y As Integer, ByVal length As Integer, ByVal colorcode1 As Integer, ByVal colorcode2 As Integer, ByVal minvalue As Integer, ByVal maxvalue As Integer, ByVal isvertical As Boolean, ByVal fieldnumber As Integer, ByVal layernumber As Integer)
        End Sub
        Public Sub Addslider(ByVal x As Integer, ByVal y As Integer, ByVal length As Integer, ByVal colorcode1 As Integer, ByVal colorcode2 As Integer, ByVal minvalue As Integer, ByVal maxvalue As Integer, ByVal isvertical As Boolean, ByVal acceptclick As Boolean, ByVal fieldnumber As Integer, ByVal layernumber As Integer)
        End Sub
        Public Sub Setslider(ByVal value As Integer, ByVal fieldnumber As Integer)
        End Sub
        Public Sub Addcomboboxitem(ByVal val As String, ByVal labelnumber As Integer)
        End Sub
        Public Sub Clearcomboboxitems(ByVal labelnumber As Integer)
        End Sub
        Public Sub Validatenewcomboboxitems(ByVal labelnumber As Integer)
        End Sub
        Public Sub Clearlist(ByVal labelnumber As Integer)
        End Sub
        Public Function Getselectedindexinlist(ByVal labelnumber As Integer) As Integer
            Return 0
        End Function
        Public Function Setselectedindexinlist(ByVal labelnumber As Integer, ByVal index As Integer) As Integer
            Return 0
        End Function
        Public Sub Addbutton(ByVal x As Double, ByVal y As Double, ByVal w As Double, ByVal h As Double, ByVal toggletype As Boolean, ByVal blinktype As Boolean, ByVal picturenumber As Integer, ByVal buttonnumber As Integer, ByVal layernumber As Integer)
        End Sub
        Public Sub Sendcolorpickertoscreen(ByVal x As Double, ByVal y As Double, ByVal w As Double, ByVal h As Double, ByVal colorpickernumber As Integer, ByVal layernumber As Integer)
        End Sub
        Public Sub Addcolorpick(ByVal x As Double, ByVal y As Double, ByVal w As Double, ByVal h As Double, ByVal colorpickernumber As Integer, ByVal layernumber As Integer)
        End Sub
        Public Sub Setcolorpickercolor(ByVal val As Integer, ByVal labelnumber As Integer)
        End Sub
        Public Function Getcolorpickercolor(ByVal labelnumber As Integer) As Integer
            Return 0
        End Function
        Public Sub Addimageview(ByVal x As Double, ByVal y As Double, ByVal w As Double, ByVal h As Double, ByVal labelnumber As Integer, ByVal layernumber As Integer)
        End Sub
        Public Sub Sendimageview(ByVal img As Image, ByVal ID As Integer)
        End Sub
        Public Sub SendLEDtoscreen(ByVal x As Double, ByVal y As Double, ByVal w As Double, ByVal h As Double, ByVal picturenumber As Integer, ByVal LEDnumber As Integer, ByVal layernumber As Integer)
        End Sub
        Public Sub Addled(ByVal x As Double, ByVal y As Double, ByVal w As Double, ByVal h As Double, ByVal picturenumber As Integer, ByVal LEDnumber As Integer, ByVal layernumber As Integer)
        End Sub
        Public Sub Addled(ByVal x As Double, ByVal y As Double, ByVal w As Double, ByVal h As Double, ByVal blinktype As Boolean, ByVal picturenumber As Integer, ByVal LEDnumber As Integer, ByVal layernumber As Integer)
        End Sub
        Public Sub Sendbackgroundtoscreen(ByVal x As Double, ByVal y As Double, ByVal w As Double, ByVal h As Double, ByVal picturenumber As Integer, ByVal backgroundnumber As Integer, ByVal layernumber As Integer)
        End Sub
        Public Sub Addbackground(ByVal x As Double, ByVal y As Double, ByVal w As Double, ByVal h As Double, ByVal picturenumber As Integer, ByVal backgroundnumber As Integer, ByVal layernumber As Integer)
        End Sub
        Public Sub Switchbutton(ByVal Ison As Boolean, ByVal Buttonnumber As Integer)
        End Sub
        Public Sub Sendallbuttonsup()
        End Sub
        Public Sub Addtexttoremember(ByVal val As String)
        End Sub
        Public Sub UpdateLEDs(ByVal LEDstates As Integer())
        End Sub
        Public Sub Sendfilltoscreen(ByVal fillcolor As Integer, ByVal posX As Integer, ByVal posY As Integer, ByVal sizeX As Integer, ByVal sizeY As Integer, ByVal transparency As Double, ByVal labelnumber As Integer, ByVal layernumber As Integer)
        End Sub
        Public Sub Addfill(ByVal fillcolor As Integer, ByVal posX As Integer, ByVal posY As Integer, ByVal sizeX As Integer, ByVal sizeY As Integer, ByVal transparency As Double, ByVal labelnumber As Integer, ByVal layernumber As Integer)
        End Sub
        Public Sub AddUCCAM(ByVal posX As Integer, ByVal posY As Integer, ByVal sizeX As Integer, ByVal sizeY As Integer, ByVal labelnumber As Integer, ByVal layernumber As Integer)
        End Sub
        Public Sub AddUCCAM(ByVal fillcolor As Integer, ByVal posX As Integer, ByVal posY As Integer, ByVal sizeX As Integer, ByVal sizeY As Integer, ByVal labelnumber As Integer, ByVal layernumber As Integer)
        End Sub
        Public Sub CAMClearcanvas(ByVal fillcolor As Integer)
        End Sub
        Public Sub ShowAllfill()
        End Sub
        Public Sub HideAllfill()
        End Sub
        Public Sub Sendcomboboxtoscreen(ByVal posX As Integer, ByVal posY As Integer, ByVal Width As Integer, ByVal fontsize As Integer, ByVal fontcolor As Integer, ByVal Numberofaxis As Integer, ByVal labelnumber As Integer, ByVal layernumber As Integer)
        End Sub
        Public Sub Addcombobox(ByVal font As String, ByVal posX As Integer, ByVal posY As Integer, ByVal Width As Integer, ByVal fontsize As Integer, ByVal fontcolor As Integer, ByVal Numberofaxis As Integer, ByVal labelnumber As Integer, ByVal layernumber As Integer)
        End Sub
        Public Sub Addcombobox(ByVal posX As Integer, ByVal posY As Integer, ByVal Width As Integer, ByVal fontsize As Integer, ByVal fontcolor As Integer, ByVal Numberofaxis As Integer, ByVal labelnumber As Integer, ByVal layernumber As Integer)
        End Sub
        Public Sub Sendstaticlabeltoscreen(ByVal labeltext As String, ByVal labelfont As String, ByVal textalign As String, ByVal fontsize As Integer, ByVal fontcolor As Integer, ByVal posX As Integer, ByVal posY As Integer, ByVal layernumber As Integer)
        End Sub
        Public Sub Addlabel(ByVal labeltext As String, ByVal labelfont As String, ByVal textalign As String, ByVal fontsize As Integer, ByVal fontcolor As Integer, ByVal posX As Integer, ByVal posY As Integer, ByVal layernumber As Integer)
        End Sub
        Public Sub Sendcodeviewtoscreen(ByVal labeltext As String, ByVal labelfont As String, ByVal textalign As String, ByVal fontsize As Integer, ByVal fontcolor As Integer, ByVal posX As Integer, ByVal posY As Integer, ByVal Width As Integer, ByVal Height As Integer, ByVal layernumber As Integer)
        End Sub
        Public Sub Addcodeview(ByVal labeltext As String, ByVal labelfont As String, ByVal textalign As String, ByVal fontsize As Integer, ByVal fontcolor As Integer, ByVal posX As Integer, ByVal posY As Integer, ByVal Width As Integer, ByVal Height As Integer, ByVal layernumber As Integer)
        End Sub
        Public Sub Updatecodeviewcolors(ByVal understandcolor As Integer, ByVal notunderstandcolor As Integer)
        End Sub
        Public Sub Sendcheckboxtoscreen(ByVal labeltext As String, ByVal labelfont As String, ByVal fontsize As Integer, ByVal fontcolor As Integer, ByVal posX As Integer, ByVal posY As Integer, ByVal boxnumber As Integer, ByVal layernumber As Integer)
        End Sub
        Public Sub Addcheckbox(ByVal labeltext As String, ByVal labelfont As String, ByVal fontsize As Integer, ByVal fontcolor As Integer, ByVal posX As Integer, ByVal posY As Integer, ByVal boxnumber As Integer, ByVal layernumber As Integer)
        End Sub
        Public Sub CAMSendimage(ByVal bmp As Image)
        End Sub
        Public Sub Setscrollproperties(ByVal max As Integer)
        End Sub
        Public Sub Setscrollposition(ByVal pos As Integer)
        End Sub
        Public Function Getfield(ByVal labelnumber As Integer) As String
            Return ""
        End Function
        Public Function GetLED(ByVal LEDnumber As Integer) As Boolean
            Return False
        End Function
        Public Sub SetLED(ByVal val As Boolean, ByVal LEDnumber As Integer)
        End Sub
        Public Function Getbuttonstate(ByVal buttonnumber As Integer) As Boolean
            Return False
        End Function
        Public Function Getbutton(ByVal buttonnumber As Integer) As Boolean
            Return False
        End Function
        Public Function Getcomboboxselection(ByVal labelnumber As Integer) As String
            Return ""
        End Function
        Public Sub Updatecomboboxselection(ByVal selectedindex As Integer, ByVal labelnumber As Integer)
        End Sub
        Public Function Getcheckboxstate(ByVal checkboxnumber As Integer) As Boolean
            Return False
        End Function
        Public Sub Setcheckboxstate(ByVal Ison As Boolean, ByVal Boxnumber As Integer)
        End Sub
        Public Function Getfieldint(ByVal labelnumber As Integer) As Integer
            Return 0
        End Function
        Public Function Getfielddouble(ByVal labelnumber As Integer) As Double
            Return 0
        End Function
        Public Function GetXMLreturnvalue(ByVal returnval As String) As String
            Return ""
        End Function
        Public Sub Sendtabtoscreen(ByVal labeltext As String, ByVal labelfont As String, ByVal textalign As String, ByVal fontsize As Integer, ByVal fontcolor As Integer, ByVal posX As Integer, ByVal posY As Integer, ByVal labelwidth As Integer, ByVal labelheight As Integer, ByVal picturenumber As Integer, ByVal labelnumber As Integer, ByVal parentnumber As Integer)
        End Sub
        Public Sub Addtab(ByVal labeltext As String, ByVal labelfont As String, ByVal textalign As String, ByVal fontsize As Integer, ByVal fontcolor As Integer, ByVal posX As Integer, ByVal posY As Integer, ByVal labelwidth As Integer, ByVal labelheight As Integer, ByVal picturenumber As Integer, ByVal labelnumber As Integer, ByVal parentnumber As Integer)
        End Sub
        Public Sub Addmainlayer()
        End Sub
        Public Sub selectlayer(ByVal layernumber As Integer)
        End Sub
        Public Sub Sendfieldtoscreen(ByVal labeltext As String, ByVal labelfont As String, ByVal textalign As String, ByVal fontsize As Integer, ByVal fontcolor As Integer, ByVal posX As Double, ByVal posY As Double, ByVal intextboxwidth As Integer, ByVal type As String, ByVal min As Double, ByVal max As Double, ByVal labelnumber As Integer, ByVal parentnumber As Integer)
        End Sub
        Public Sub Addfield(ByVal labeltext As String, ByVal labelfont As String, ByVal textalign As String, ByVal fontsize As Integer, ByVal fontcolor As Integer, ByVal posX As Double, ByVal posY As Double, ByVal intextboxwidth As Integer, ByVal type As String, ByVal min As Double, ByVal max As Double, ByVal labelnumber As Integer, ByVal parentnumber As Integer)
        End Sub
        Public Sub Setfield(ByVal val As Double, ByVal labelnumber As Integer)
        End Sub
        Public Sub Validatefield(ByVal labelnumber As Integer)
        End Sub
        Public Sub Focusoutoffield()
        End Sub
        Public Sub Setinputnumberformat(ByVal Fixeddecimal As Boolean, ByVal Decimalplaces As Integer, ByVal labelnumber As Integer)
        End Sub
        Public Sub Filterinputtext(ByVal val As String, ByVal labelnumber As Integer)
        End Sub
        Public Sub Filterfieldtext(ByVal val As String, ByVal labelnumber As Integer)
        End Sub
        Public Sub Setfieldtext(ByVal val As String, ByVal labelnumber As Integer)
        End Sub
        Public Sub SendMDItoscreen(ByVal labeltext As String, ByVal labelfont As String, ByVal textalign As String, ByVal fontsize As Integer, ByVal fontcolor As Integer, ByVal posX As Integer, ByVal posY As Integer, ByVal intextboxwidth As Integer, ByVal labelnumber As Integer, ByVal parentnumber As Integer)
        End Sub
        Public Sub Addmdi(ByVal labeltext As String, ByVal labelfont As String, ByVal textalign As String, ByVal fontsize As Integer, ByVal fontcolor As Integer, ByVal posX As Integer, ByVal posY As Integer, ByVal intextboxwidth As Integer, ByVal labelnumber As Integer, ByVal parentnumber As Integer)
        End Sub
        Public Sub BlinkMDI(ByVal codeOK As Integer, ByVal labelnumber As Integer)
        End Sub
        Public Sub Addtoolpath(ByVal x As Integer, ByVal y As Integer, ByVal width As Integer, ByVal height As Integer, ByVal layer As Integer)
        End Sub
    End Class
End Namespace