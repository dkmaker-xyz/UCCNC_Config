﻿Namespace UCCNC
    Public Structure Allvarstruct
        Public Avar As Double?
        Public Bvar As Double?
        Public Cvar As Double?
        Public Dvar As Double?
        Public Evar As Double?
        Public Fvar As Double?
        Public Gvar As Double?
        Public Hvar As Double?
        Public Ivar As Double?
        Public Jvar As Double?
        Public Kvar As Double?
        Public Lvar As Double?
        Public Mvar As Double?
        Public Nvar As Double?
        Public Ovar As Double?
        Public Pvar As Double?
        Public Qvar As Double?
        Public Rvar As Double?
        Public Svar As Double?
        Public Tvar As Double?
        Public Uvar As Double?
        Public Vvar As Double?
        Public Wvar As Double?
        Public Xvar As Double?
        Public Yvar As Double?
        Public Zvar As Double?
        Public Isvar As Boolean
    End Structure
End Namespace