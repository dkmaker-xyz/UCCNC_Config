﻿Imports System
Imports System.Collections.Generic
Imports System.Diagnostics
Imports System.Windows.Forms
Imports System.ComponentModel

Namespace UCCNC
    Public Class Form1
        Inherits Form
        Public Shared Function ApplicationIsActivated() As Boolean
            Return False
        End Function
        Public Shared Function GetKeyboardState(ByVal keystate As Byte()) As Integer
            Return 0
        End Function
        Public Shared Function convertFloatsToDoubles(ByVal input As Single()) As Double()
            Return New Double(-1) {}
        End Function

        Public loadfileworker As BackgroundWorker
        Public ownprogressbar As PictureBox
        Public label10 As Label
        Public jogcontrol1 As Panel
        Public timer2 As Timer
        Public starthiderpanel As Panel
        'public OpenTK.GLControl glControl2;
        'public OpenTK.GLControl glControl3;
        'public OpenTK.GLControl glControl1;
        Public panel1 As Panel
        Public Savesettingspanel As Panel
        Public Savesettingslabel As Label
        Public Softwareversion As String
        'public UCCNC.WebCAM camera;
        Public toolTip As ToolTip
        Public Refreshtoolpathdisabledstate As Boolean
        Public changingvertex As Boolean
        Public loadingvertex As Boolean
        Public knifeangle As Single
        Public eFROover100 As Boolean
        Public eFROunder100 As Boolean
        Public eSROover100 As Boolean
        Public eSROunder100 As Boolean
        Public colorBufferId As UInteger
        Public DcolorBufferId As UInteger
        Public Dvertexbuffer As Single()
        'public OpenTK.Vector3[] Dcolortablepath;
        Public Startedup As Boolean
        Public Savingsettingsnow As Boolean
        Public Saveonclosingnow As Boolean
        Public Screenloading As Boolean
        Public Screencallsumnum As Integer
        Public Screencalls As Integer
        Public Coordsupdate As Boolean
        Public Applyingsettingsnow As Boolean
        Public DonotenterDROonce As Boolean
        'public UCCNC.Spindlepulleys Pulleys;
        Public jogdisabled As Boolean
        Public RestartApp As Boolean
        Public RestartArgs As String
        'public UCCNC.Compressionmethod GLavailabelcompressionmethod;
        'public UCCNC.Macroloopconfig Macroloopconfigwindow;
        'public UCCNC.Macroloop[] Macroloops;
        Public messagequeqe As List(Of String)
        Public maxlayernumber As Integer
        Public screensetfilename As String
        Public minobjsize As Double
        Public minlistsizeX As Double
        Public minlistsizeY As Double
        Public mincomboboxsizeX As Double
        Public currentclickedlayer As Integer
        Public OpenGLversion As Double
        Public IsopenGLversionOK As Boolean
        Public UseARB_vertex_buffer_object As Boolean
        Public IsopenGL_anisotropic_supported As Boolean
        Public IsopenGL_nonpoweroftwo_supported As Boolean
        'public UCCNC.Screeneditor se;
        Public Isscreenedit As Boolean
        'public UCCNC.Playback Audio;
        Public jogscreensizeX As Integer
        Public jogscreensizeY As Integer
        Public mainscreensizeX As Integer
        Public mainscreensizeY As Integer
        Public showrow As Integer
        'public UCCNC.Comboselector Combo;
        Public maxtabnum As Integer
        'public UCCNC.GUIevents mainGUIevents;
        Public Buttonsdetails As List(Of UCCNC.Functionproperties)
        Public LEDsdetails As List(Of UCCNC.Functionproperties)
        Public Doshutdown As Boolean
        Public Pluginsloaded As Boolean
        Public Pluginsstarted As Boolean
        'public List<UCCNC.Pluginthread> Pthread;
        'public UCCNC.Plugins UCplugins;
        Public Didmainformpreparation As Boolean
        Public Didjogbuildpreparation As Boolean
        Public splashscreennumber As Integer
        Public jogbuilt As Boolean
        Public mainbuilt As Boolean
        Public firststart As Boolean
        Public startscreenerror As Boolean
        'public UCCNC.UCCAMinterface cam;
        Public maxlabelnum As Integer
        Public checkboxnum As Integer
        Public comboboxnum As Integer
        Public labelnum As Integer
        Public keyboardkeys As Boolean()
        Public keysstatic As Boolean()
        Public ekeysstatic As Boolean()
        Public demomode As Boolean
        Public forceclose As Boolean
        Public userselecteddevice As Integer
        'public UC100.DeviceType userselecteddevtype;
        'public UCCNC.Portandpindef[] actpindef;
        'public UCCNC.Analogports analogdef;
        Public maxport As Integer
        Public maxpin As Integer
        Public maxAnaInport As Integer
        Public maxAnaOutport As Integer
        Public firstcycleUC300demooutpinsfix As Boolean
        'public UCCNC.Inputtrigger intrig;
        'public UCCNC.Hotkeytrigger hottrig;
        'public UCCNC.Outputtrigger outtrig;
        Public hottriggerfirsttime As Boolean
        Public xjogging As Boolean
        Public yjogging As Boolean
        Public zjogging As Boolean
        Public ajogging As Boolean
        Public bjogging As Boolean
        Public cjogging As Boolean
        Public anyDROinfocus As Boolean
        Public MSG As UCCNC.Systemmessages
        Public Connectionerrorhappened As Boolean
        Public m30line As Integer
        Public stopwatch As Stopwatch
        Public sysruntime As Stopwatch
        Public hidesetup As Boolean
        Public ehidesetup As Boolean
        Public Statuslistbox As ListBox
        'public UCCNC.Sumoffsetcontrol sumoffsetcontrol1;
        'public UCCNC.axisDROcontrol AxisDRO;
        'public UCCNC.UC100setup UCsetup;
        Public isclosing As Boolean
        Public disablelayerchange As Boolean
        Public buttonbuildends As Boolean
        Public screenbuilds As Integer
        Public jogtab As Integer
        'public UCCNC.UC100IOmonitor UC100IOmonitor1;
        'public UCCNC.resetbuttoncontrol resetbuttoncontrol1;
        'public UCCNC.Profilesetup ProfileControl1;
        Public actuallayer As Integer
        Public toolpathlayer As Integer
        Public AS3 As UCCNC.AS3interfaceClass
        Public AS3jog As UCCNC.AS3interfaceClass
        Public arguments As String()
        'public UCCNC.Screenbuilder Screenbuildinstance;
        'public UCCNC.Loadsavesettings LS;
        Public boxselected As Boolean
        Public vertexbuffer As Single()
        Public arrowvertexbuffer As Single()
        Public conevertexbuffer As Single()
        Public cursorcolor As Integer
        Public screenbackcolor As Integer
        'public UCCNC.Makedrawing mk;
        Public keyjogon As Boolean
        'public UCCNC.Mymessagebox mg;
        'public UCCNC.GInterpreter Gpret;
        'public UCCNC.GInterpreter Mpret;
        Public xp As Double
        Public yp As Double
        Public zp As Double
        Public ap As Double
        Public bp As Double
        Public cp As Double
        Public xpd As Double
        Public ypd As Double
        Public zpd As Double
        Public apd As Double
        Public bpd As Double
        Public cpd As Double
        Public havetoupdatescreen As Boolean
        Public codebeginning As Boolean
        Public actuallinetoexecute As Integer
        Public UCstat As UC100.Stat
        Public Inputpins As Long
        'public UC100.SPSetting SPset;
        Public exec As UCCNC.Executer
        Public updatewaittime As Integer
        Public viewerupdate As Integer
        Public tilldonepath As Integer
        Public etilldonepath As Integer
        Public fromdonepath As Integer
        Public filenametoload As String
        'public UCCNC.SpindlePID SpindlePIDForm;
        'public UCCNC.Startupscreen splash;

        'public void Deletelaserimage(int imagenum) { }
        'public int Loadimage(Drawing.Image img) { return 0; }
        'public void Getborderandmarksize() { }
        'public void makedims() { }
        'public void Drawdimsimages() { }
        'public int Drawdimsimage(string text, float Length, float Arany, float diffX, float diffY, bool rotate, Drawing.Color col) { return 0; }
        'public void Seletscreenset() { }
        'public void Cameracapturetoggle() { }
        'public void Cameracaptureon() { }
        'public void Cameracaptureoff() { }
        'public void Reloadcameracapturedevicelist() { }
        'public void Movecameraoffset() { }
        'public void Cameragrayscalefiltertoggle() { }
        'public void Cameragrayscalefilteron() { }
        'public void Cameragrayscalefilteroff() { }
        'public void Cameraedgefiltertoggle() { }
        'public void Cameraedgefilteron() { }
        'public void Cameraedgefilteroff() { }
        'public void Increasecameratargetcircles() { }
        'public void Decreasecameratargetcircles() { }
        'public void Cameratargetlinetoggle() { }
        'public void Cameratargetlineon() { }
        'public void Cameratargetlineoff() { }
        'public void MovetocameraZheight() { }
        'public void Camerainvertimagetoggle() { }
        'public void Camerainvertimageon() { }
        'public void Camerainvertimageoff() { }
        'public void Setview45() { }
        'public void Setviewleft() { }
        'public void Setviewright() { }
        'public void Setviewtop() { }
        'public void Changeview() { }
        'public void DoXMLimport() { }
        'public void M3press() { }
        'public void M3doon() { }
        'public void M3dooff() { }
        'public void M4press() { }
        'public void M4doon() { }
        'public void M4dooff() { }
        'public void M7press() { }
        'public void M7doon() { }
        'public void M7dooff() { }
        'public void M8press() { }
        'public void M8doon() { }
        'public void M8dooff() { }
        'public void Setloadbarnewpos() { }
        'public void fitglcontrolsize() { }
        'public void hidejogger() { }
        'public void showjogger() { }
        'public void Hotkeyscheck() { }
        'public double Rollovercoords(double Val) { return 0; }
        'public void CAMCreatecode() { }
        'public void CAMGeneratepath() { }
        'public void CAMLoadDXF() { }
        'public void Comboboxselectionchanged(int boxnumber) { }
        'public void Mainformpreparation() { }
        'public void Closethisform(string errorstring) { }
        'public void Jogbuildpreparation() { }
        'public void Configuremacroloops() { }
        'public void Configureplugins() { }
        'public void Pluginshowupcaller(int pluginnumber) { }
        'public void Editscreen() { }
        'public void JogOff(int axis) { }
        'public void Toolpathhighlightcalc() { }
        'public string formatnumber1(Decimal Value) { return ""; }
        'public void ActivateForm() { }
        'public void TCPfollowon() { }
        'public void TCPfollowoff() { }
        'public void ToggleTCPfollow() { }
        'public void ShowZplatesetupWindow() { }
        'public void Initttooltip() { }
        'public string Getlicensename() { return ""; }
        'public bool IsProcessOpen(string name) { return false; }
        'public UCCNC.Compressionmethod GetOpenGLtexturecompressionmethod() { return new UCCNC.Compressionmethod(); }
        'public void setscreenrefreshrate(int vertexcount) { }
        'public void Setupsettings() { }
        'public void DoM5() { }
        'public void DoM9() { }
        'public void stopcodeexecution() { }
        'public void Fileload() { }
        'public void loadfile() { }
        'public void Filerewind() { }
        'public void Fileclose() { }
        'public void Setnextlinebuttonclicked(string linenumber) { }
        'public void Cyclestop() { }
        'public void Interpretmacrocode(string sender) { }
        'public void Interpretmacrolist(List<string> sender) { }
        'public void SendMDI(string MDItext, bool doMDIblink) { }
        'public void SendMDIthread() { }
        'public void setoffset(int G5x) { }
        'public void offlinepressed() { }
        'public void offlineon() { }
        'public void offlineoff() { }
        'public void Fileedit() { }
        'public void screenredrawcycle() { }
        'public void screenredrawcycle_clear() { }
        'public void screenredrawcycle_real() { }
        'public void Getclickedpoint(OpenTK.Vector2 our2DPoint) { }
        'public OpenTK.Vector3 from2Dto3D(OpenTK.Vector2 our2DPoint) { return new OpenTK.Vector3(); }
        'public OpenTK.Vector2 from3Dto2D(OpenTK.Vector3 our3DPoint) { return new OpenTK.Vector2(); }
        'public void makearrows() { }
        'public void makeZzeroplate() { }
        'public void makefloor() { }
        'public void resetscreen() { }
        'public void Zoomcontents() { }
        'public void Zoomminus() { }
        'public void Zoomplus() { }
        'public void SetviewISO() { }
    End Class
End Namespace