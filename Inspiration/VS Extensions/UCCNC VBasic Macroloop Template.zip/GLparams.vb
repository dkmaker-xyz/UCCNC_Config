﻿Namespace UCCNC
    Public Structure GLparams
        Public x As Integer
        Public y As Integer
        Public width As Integer
        Public height As Integer
        Public visible As Boolean
    End Structure
End Namespace