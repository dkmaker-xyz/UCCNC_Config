﻿Namespace Plugininterface.Datatypes
    Public Structure Layerdatastruct
        Public Isactive As Boolean
        Public Layernumber As Integer
        Public Parentnumber As Integer
    End Structure
End Namespace