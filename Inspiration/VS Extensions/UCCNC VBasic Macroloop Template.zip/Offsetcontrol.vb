﻿Namespace UCCNC
    Public Class Offsetcontrol
        Public Number As Integer
        Public TOZval As Double
        Public Wxval As Double
        Public Wyval As Double
        Public Wzval As Double
        Public Waval As Double
        Public Wbval As Double
        Public Wcval As Double
        Public Mxval As Double
        Public Myval As Double
        Public Mzval As Double
        Public Maval As Double
        Public Mbval As Double
        Public Mcval As Double
        Public Cxval As Double
        Public Cyval As Double
        Public Czval As Double
        Public Caval As Double
        Public Cbval As Double
        Public Ccval As Double
        Public G92xval As Double
        Public G92yval As Double
        Public G92zval As Double
        Public G92aval As Double
        Public G92bval As Double
        Public G92cval As Double
        'public UCCNC.Form1 mainform;

        Public Function fitnumseparator(ByVal num As String) As String
            Return ""
        End Function
        Public Sub setnewTOZ(ByVal val As Double)
        End Sub
        Public Sub setnewG92x(ByVal val As Double)
        End Sub
        Public Sub setnewG92y(ByVal val As Double)
        End Sub
        Public Sub setnewG92z(ByVal val As Double)
        End Sub
        Public Sub setnewG92a(ByVal val As Double)
        End Sub
        Public Sub setnewG92b(ByVal val As Double)
        End Sub
        Public Sub setnewG92c(ByVal val As Double)
        End Sub
        Public Sub setnewWx(ByVal val As Double)
        End Sub
        Public Sub setnewWy(ByVal val As Double)
        End Sub
        Public Sub setnewWz(ByVal val As Double)
        End Sub
        Public Sub setnewWa(ByVal val As Double)
        End Sub
        Public Sub setnewWb(ByVal val As Double)
        End Sub
        Public Sub setnewWc(ByVal val As Double)
        End Sub
        Public Sub newCxinput(ByVal val As Double)
        End Sub
        Public Sub newCyinput(ByVal val As Double)
        End Sub
        Public Sub newCzinput(ByVal val As Double)
        End Sub
        Public Sub newCainput(ByVal val As Double)
        End Sub
        Public Sub newCbinput(ByVal val As Double)
        End Sub
        Public Sub newCcinput(ByVal val As Double)
        End Sub
        Public Sub setnewCx(ByVal val As Double)
        End Sub
        Public Sub setnewCy(ByVal val As Double)
        End Sub
        Public Sub setnewCz(ByVal val As Double)
        End Sub
        Public Sub setnewCa(ByVal val As Double)
        End Sub
        Public Sub setnewCb(ByVal val As Double)
        End Sub
        Public Sub setnewCc(ByVal val As Double)
        End Sub
    End Class
End Namespace