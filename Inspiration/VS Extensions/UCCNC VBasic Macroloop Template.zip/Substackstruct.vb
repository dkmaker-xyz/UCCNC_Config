﻿Namespace UCCNC
    Public Structure Substackstruct
        Public substartID As Integer
        Public subreturnID As Integer
        Public numberofcalls As Integer
        Public callcounter As Integer
    End Structure
End Namespace