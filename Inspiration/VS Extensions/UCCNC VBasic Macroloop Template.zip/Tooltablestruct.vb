﻿Namespace Plugininterface.Datatypes
    Public Structure Tooltablestruct
        Public Description As String
        Public Dia As Double
        Public Material As String
        Public OffsetZ As Double
        Public Slot As Integer
        Public Toolnumber As Integer
        Public Type As String
    End Structure
End Namespace